package de.bomaex.bmos

import android.annotation.SuppressLint
import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.app.WallpaperManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.graphics.BitmapFactory
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.os.Message
import android.util.Base64
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.os.PowerManager
import android.os.Process
import android.view.ViewGroup
import android.webkit.RenderProcessGoneDetail
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.ValueCallback
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/**
 * BM OS: dünne Hülle um den Launcher auf https://www.bomaex.de/bmos/.
 * Alles, was im Launcher selbst passiert, wird per FTP aktualisiert, ohne neue APK.
 */
class MainActivity : Activity() {

    companion object {
        const val START_URL = "https://www.bomaex.de/bmos/"
        const val TRUSTED_HOST = "www.bomaex.de"
        const val TRUSTED_PATH = "/bmos"
    }

    private lateinit var web: WebView

    // 0.4: meldet dem Launcher, wenn eine App installiert, aktualisiert oder entfernt wurde (Ereignis "bmpkg")
    private var pkgReceiver: BroadcastReceiver? = null

    // Dateiauswahl (Hintergrundbild, Import) und native Spracherkennung
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var sr: SpeechRecognizer? = null
    @Volatile
    private var assistPending = false

    private fun isAssist(i: Intent?): Boolean =
        i != null && (i.action == Intent.ACTION_ASSIST || i.action == Intent.ACTION_VOICE_COMMAND || i.action == WakeService.ACTION_ASSIST)

    // Nur die eigene Launcher-Seite darf die Brücke BMNative benutzen.
    @Volatile
    private var trusted = false

    private fun isLauncherUrl(url: String?): Boolean {
        if (url == null) return false
        val u = Uri.parse(url)
        return u.scheme == "https" && u.host == TRUSTED_HOST &&
            (u.path ?: "").startsWith(TRUSTED_PATH)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildWeb()
        registerPkgReceiver()
        if (isAssist(intent)) assistPending = true
        askBatteryOnce()
        // „Hey Bo“ nach einem App-Neustart wieder einschalten, wenn der Nutzer es angeschaltet hat
        if (getSharedPreferences("bmos", Context.MODE_PRIVATE).getBoolean("wake", false) && hasMic()) WakeService.start(this)
        if (savedInstanceState == null) web.loadUrl(START_URL) else web.restoreState(savedInstanceState)
    }

    private fun registerPkgReceiver() {
        if (pkgReceiver != null) return
        val r = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, i: Intent?) {
                if (!trusted) return
                web.post { web.evaluateJavascript("window.dispatchEvent(new Event('bmpkg'))", null) }
            }
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        try {
            registerReceiver(r, f)
            pkgReceiver = r
        } catch (e: Exception) {
        }
    }

    /** Fragt einmalig, ob BM OS von der Akku-Sparfunktion ausgenommen wird. Sonst beendet Android den Launcher im Hintergrund und er muss neu laden. */
    private fun askBatteryOnce() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val sp = getSharedPreferences("bmos", Context.MODE_PRIVATE)
            if (!pm.isIgnoringBatteryOptimizations(packageName) && !sp.getBoolean("batAsked", false)) {
                sp.edit().putBoolean("batAsked", true).apply()
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
        } catch (e: Exception) {
        }
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    private fun buildWeb() {
        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            allowFileAccess = false
            allowContentAccess = false
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
            mediaPlaybackRequiresUserGesture = true
        }
        web.setBackgroundColor(0xFF0A101D.toInt())
        // Der WebView-Prozess bleibt auch im Hintergrund wichtig, damit der Launcher beim Zurückkommen sofort da ist
        if (Build.VERSION.SDK_INT >= 26) web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
        web.addJavascriptInterface(Bridge(), "BMNative")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                if (isLauncherUrl(url)) return false
                openExternal(url)
                return true
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                trusted = isLauncherUrl(url)
            }

            // Wird der WebView-Prozess von Android beendet: neu aufbauen statt abstürzen
            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                trusted = false
                (view.parent as? ViewGroup)?.removeView(view)
                view.destroy()
                buildWeb()
                web.loadUrl(START_URL)
                return true
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    trusted = false
                    view.loadUrl("file:///android_asset/offline.html")
                }
            }
        }

        // target="_blank" und window.open: im Standardbrowser öffnen, Launcher bleibt stehen
        web.webChromeClient = object : WebChromeClient() {
            // Dateiauswahl (z. B. eigenes Hintergrundbild): ohne diese Funktion öffnet der WebView nichts
            override fun onShowFileChooser(view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                if (!trusted) { callback.onReceiveValue(null); return true }
                fileCb?.onReceiveValue(null)
                fileCb = callback
                return try {
                    startActivityForResult(params.createIntent(), 77)
                    true
                } catch (e: Exception) {
                    fileCb = null
                    callback.onReceiveValue(null)
                    true
                }
            }

            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                val temp = WebView(this@MainActivity)
                temp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean {
                        openExternal(request.url.toString())
                        v.post { v.destroy() }
                        return true
                    }
                }
                (resultMsg.obj as WebView.WebViewTransport).webView = temp
                resultMsg.sendToTarget()
                return true
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    // Home-Taste, während der Launcher schon läuft
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (isAssist(intent)) {
            web.evaluateJavascript("window.dispatchEvent(new Event('bmassist'))", null)
        } else if (intent.hasCategory(Intent.CATEGORY_HOME)) {
            web.evaluateJavascript("window.dispatchEvent(new Event('bmhome'))", null)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 77) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
            return
        }
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
    }

    private fun hasMic() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    // ---------- Native Spracherkennung (Android-WebView hat keine eigene) ----------

    private fun srEmit(o: JSONObject) {
        val js = "window.bmSrEvent&&window.bmSrEvent(" + JSONObject.quote(o.toString()) + ")"
        runOnUiThread { web.evaluateJavascript(js, null) }
    }

    private fun srErr(code: String) {
        srEmit(JSONObject().put("t", "error").put("c", code))
        srEmit(JSONObject().put("t", "end"))
    }

    private fun srList(b: Bundle?): JSONArray {
        val arr = JSONArray()
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.forEach { arr.put(it) }
        return arr
    }

    private fun srBegin(lang: String) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { srErr("unsupported"); return }
        try { sr?.destroy() } catch (e: Exception) { }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                val a = srList(partialResults)
                if (a.length() > 0) srEmit(JSONObject().put("t", "partial").put("a", a))
            }
            override fun onResults(results: Bundle?) {
                val a = srList(results)
                if (a.length() > 0) srEmit(JSONObject().put("t", "final").put("a", a))
                srEmit(JSONObject().put("t", "end"))
            }
            override fun onError(error: Int) {
                val code = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "no-speech"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "not-allowed"
                    SpeechRecognizer.ERROR_AUDIO -> "audio-capture"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> "network"
                    else -> "aborted"
                }
                srErr(code)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        try { r.startListening(i) } catch (e: Exception) { srErr("aborted") }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 3 && hasMic() && getSharedPreferences("bmos", Context.MODE_PRIVATE).getBoolean("wake", false)) {
            WakeService.start(this)
        }
        web.evaluateJavascript("window.dispatchEvent(new Event('bmperm'))", null)
    }

    // Ein Launcher beendet sich nie: Zurück geht nur im Verlauf, sonst nichts
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onPause() {
        web.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        try { sr?.destroy() } catch (e: Exception) { }
        try { pkgReceiver?.let { unregisterReceiver(it) } } catch (e: Exception) { }
        pkgReceiver = null
        web.destroy()
        super.onDestroy()
    }

    // ---------- Hilfsfunktionen ----------

    private fun openExternal(url: String) {
        try {
            if (url.startsWith("intent:")) {
                val intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                intent.addCategory(Intent.CATEGORY_BROWSABLE)
                intent.component = null
                intent.selector = null
                try {
                    startActivity(intent)
                } catch (e: ActivityNotFoundException) {
                    val fb = intent.getStringExtra("browser_fallback_url")
                    if (fb != null && fb.startsWith("https://")) openExternal(fb)
                }
                return
            }
            val scheme = Uri.parse(url).scheme
            if (scheme == "https" || scheme == "http" || scheme == "mailto" || scheme == "tel" || scheme == "market") {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        } catch (e: Exception) {
            // ungültige Adresse oder keine passende App: ignorieren
        }
    }

    private fun drawableToPng(d: Drawable, size: Int): String {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        d.setBounds(0, 0, size, size)
        d.draw(c)
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        bmp.recycle()
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    // ---------- Brücke zum Launcher (window.BMNative) ----------

    inner class Bridge {

        /** Liste aller startbaren Apps als JSON: [{n: Name, p: Paket, i: Symbol als data-URI}] */
        @JavascriptInterface
        fun apps(): String {
            if (!trusted) return "[]"
            val pm = packageManager
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(main, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { Triple(it.loadLabel(pm).toString(), it.activityInfo.packageName, it) }
                .distinctBy { it.second }
                .sortedBy { it.first.lowercase() }
            val arr = JSONArray()
            for ((name, pkg, info) in list) {
                val o = JSONObject()
                o.put("n", name)
                o.put("p", pkg)
                o.put("i", drawableToPng(info.loadIcon(pm), 96))
                arr.put(o)
            }
            return arr.toString()
        }

        /** Startet eine installierte App; ist sie nicht da, öffnet sich ihre Play-Store-Seite. */
        @JavascriptInterface
        fun launch(pkg: String) {
            if (!trusted || !Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$").matches(pkg)) return
            val intent = packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            } else {
                play(pkg)
            }
        }

        /** Öffnet den Play Store. */
        @JavascriptInterface
        fun playStore() {
            if (!trusted) return
            val intent = packageManager.getLaunchIntentForPackage("com.android.vending")
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            } else {
                openExternal("https://play.google.com/store")
            }
        }

        /** Öffnet die Play-Store-Seite eines Pakets. */
        @JavascriptInterface
        fun play(pkg: String) {
            if (!trusted || !Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$").matches(pkg)) return
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: ActivityNotFoundException) {
                openExternal("https://play.google.com/store/apps/details?id=$pkg")
            }
        }

        // ---------- Benachrichtigungen ----------

        /** Zähler pro App als JSON: {"com.whatsapp": 3, ...}. Braucht die Freigabe in den Systemeinstellungen. */
        @JavascriptInterface
        fun notifications(): String {
            if (!trusted) return "{}"
            val o = JSONObject()
            NotifService.counts.forEach { (k, v) -> o.put(k, v) }
            return o.toString()
        }

        @JavascriptInterface
        fun hasNotificationAccess(): Boolean {
            if (!trusted) return false
            val list = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            return list?.contains(packageName) == true
        }

        /** Öffnet die Systemseite, auf der der Nutzer BM OS den Zugriff auf Benachrichtigungen erlaubt. */
        @JavascriptInterface
        fun openNotificationSettings() {
            if (!trusted) return
            startActivity(
                Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }

        // ---------- Kontakte ----------

        @JavascriptInterface
        fun hasContacts(): Boolean =
            trusted && checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

        /** Fragt die Berechtigung an. Danach feuert im Launcher das Ereignis "bmperm". */
        @JavascriptInterface
        fun requestContacts() {
            if (!trusted) return
            runOnUiThread { requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 1) }
        }

        /** Kontakte als JSON: [{n: Name, t: Nummer, s: 1 wenn Favorit}], optional mit Suchtext. */
        @JavascriptInterface
        fun contacts(query: String): String {
            if (!hasContacts()) return "[]"
            val q = query.trim()
            val arr = JSONArray()
            val phone = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val sel = if (q.isEmpty()) null else "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
            val args = if (q.isEmpty()) null else arrayOf("%$q%")
            contentResolver.query(
                phone,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.STARRED
                ),
                sel, args,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} COLLATE LOCALIZED ASC"
            )?.use { c ->
                var n = 0
                while (c.moveToNext() && n < 300) {
                    val o = JSONObject()
                    o.put("n", c.getString(0) ?: "")
                    o.put("t", c.getString(1) ?: "")
                    o.put("s", if (c.getInt(2) == 1) 1 else 0)
                    arr.put(o)
                    n++
                }
            }
            return arr.toString()
        }

        private val phoneRegex = Regex("^[0-9+*#() \\-]{3,30}$")

        /** Öffnet die Telefon-App mit der Nummer (der Nutzer drückt selbst auf Anrufen). */
        @JavascriptInterface
        fun dial(number: String) {
            if (!trusted || !phoneRegex.matches(number)) return
            startActivity(
                Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }

        /** Öffnet die Nachrichten-App an die Nummer. */
        @JavascriptInterface
        fun sms(number: String) {
            if (!trusted || !phoneRegex.matches(number)) return
            startActivity(
                Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }

        // ---------- Gerät ----------

        /** {"level": 0-100, "charging": true/false} */
        @JavascriptInterface
        fun battery(): String {
            val o = JSONObject()
            if (!trusted) return o.toString()
            val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            o.put("level", if (level >= 0 && scale > 0) level * 100 / scale else -1)
            o.put("charging", status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL)
            return o.toString()
        }

        /** {"online": true/false, "type": "wifi" | "mobil" | "andere" | "keins"} */
        @JavascriptInterface
        fun network(): String {
            val o = JSONObject()
            if (!trusted) return o.toString()
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            val online = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
            o.put("online", online)
            o.put(
                "type", when {
                    caps == null -> "keins"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobil"
                    else -> "andere"
                }
            )
            return o.toString()
        }

        /** Taschenlampe an oder aus. Gibt true zurück, wenn es geklappt hat. */
        @JavascriptInterface
        fun torch(on: Boolean): Boolean {
            if (!trusted) return false
            return try {
                val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.firstOrNull {
                    cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                } ?: return false
                cm.setTorchMode(id, on)
                true
            } catch (e: Exception) {
                false
            }
        }

        /** Kurz vibrieren (1 bis 500 Millisekunden). */
        @JavascriptInterface
        fun vibrate(ms: Int) {
            if (!trusted) return
            val t = ms.coerceIn(1, 500).toLong()
            val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(t, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(t)
            }
        }

        // ---------- Zuletzt benutzte Apps und Symbole ----------

        @Suppress("DEPRECATION")
        @JavascriptInterface
        fun hasUsageAccess(): Boolean {
            if (!trusted) return false
            return try {
                val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
                ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
            } catch (e: Exception) {
                false
            }
        }

        @JavascriptInterface
        fun openUsageSettings() {
            if (!trusted) return
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }

        /** Zuletzt auf dem Handy genutzte Apps als JSON: [{n: Name, p: Paket}], neueste zuerst. */
        @Suppress("DEPRECATION")
        @JavascriptInterface
        fun recents(): String {
            val arr = JSONArray()
            if (!hasUsageAccess()) return arr.toString()
            try {
                val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
                val end = System.currentTimeMillis()
                val ev = usm.queryEvents(end - 3L * 86400000L, end)
                val e = UsageEvents.Event()
                val last = HashMap<String, Long>()
                while (ev.hasNextEvent()) {
                    ev.getNextEvent(e)
                    if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last[e.packageName] = e.timeStamp
                }
                val pm = packageManager
                last.entries.sortedByDescending { it.value }
                    .map { it.key }
                    .filter { it != packageName && pm.getLaunchIntentForPackage(it) != null }
                    .take(8)
                    .forEach { pkg ->
                        val o = JSONObject()
                        o.put("n", pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString())
                        o.put("p", pkg)
                        arr.put(o)
                    }
            } catch (e: Exception) {
            }
            return arr.toString()
        }

        /** Symbol einer installierten App als data-URI (leer, wenn nicht gefunden). */
        @JavascriptInterface
        fun icon(pkg: String): String {
            if (!trusted || !Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$").matches(pkg)) return ""
            return try {
                drawableToPng(packageManager.getApplicationIcon(pkg), 96)
            } catch (e: Exception) {
                ""
            }
        }

        // ---------- Sprache, Assistent, „Hey Bo“ ----------

        /** Startet die native Spracherkennung. Ergebnisse kommen als Ereignisse an window.bmSrEvent. */
        @JavascriptInterface
        fun srStart(lang: String): Boolean {
            if (!trusted) return false
            if (!hasMic()) {
                runOnUiThread { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2) }
                srErr("not-allowed")
                return true
            }
            val l = if (Regex("^[a-z]{2}(-[A-Za-z]{2})?$").matches(lang)) lang else "de-DE"
            runOnUiThread { srBegin(l) }
            return true
        }

        @JavascriptInterface
        fun srStop() {
            if (!trusted) return
            runOnUiThread { try { sr?.stopListening() } catch (e: Exception) { } }
        }

        @JavascriptInterface
        fun srCancel() {
            if (!trusted) return
            runOnUiThread { try { sr?.cancel() } catch (e: Exception) { } }
        }

        /** true, wenn die App durch Assistent-Taste oder „Hey Bo“ gestartet wurde (einmalig). */
        @JavascriptInterface
        fun takeAssist(): Boolean {
            if (!trusted) return false
            val v = assistPending
            assistPending = false
            return v
        }

        /** {"on": Dienst gewünscht, "model": "none|download|ready|error", "err": Text, "mic": Mikrofon erlaubt, "overlay": Einblenden erlaubt} */
        @JavascriptInterface
        fun wakeState(): String {
            val o = JSONObject()
            if (!trusted) return o.toString()
            o.put("on", getSharedPreferences("bmos", Context.MODE_PRIVATE).getBoolean("wake", false))
            o.put("model", WakeService.status)
            o.put("err", WakeService.error)
            o.put("mic", hasMic())
            o.put("overlay", Settings.canDrawOverlays(this@MainActivity))
            return o.toString()
        }

        /** Schaltet „Hey Bo“ ein oder aus. Fragt bei Bedarf Mikrofon und Benachrichtigungen an. */
        @JavascriptInterface
        fun wakeSet(on: Boolean) {
            if (!trusted) return
            getSharedPreferences("bmos", Context.MODE_PRIVATE).edit().putBoolean("wake", on).apply()
            if (!on) { WakeService.stop(this@MainActivity); return }
            runOnUiThread {
                val need = ArrayList<String>()
                if (!hasMic()) need.add(Manifest.permission.RECORD_AUDIO)
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    need.add(Manifest.permission.POST_NOTIFICATIONS)
                }
                if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 3)
                if (hasMic()) WakeService.start(this@MainActivity)
            }
        }

        /** Systemseite „Über anderen Apps einblenden“ für BM OS. */
        @JavascriptInterface
        fun openOverlaySettings() {
            if (!trusted) return
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }

        /** Systemseite, auf der man den Standard-Assistenten wählt. */
        @JavascriptInterface
        fun openAssistSettings() {
            if (!trusted) return
            try {
                startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }

        /** Öffnet die Android-Einstellungen. */
        @JavascriptInterface
        fun openSettings() {
            if (!trusted) return
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }

        // ---------- Neu in 0.4 ----------

        private val pkgRegex = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")

        /** Versionsname der Hülle, z. B. "0.4". Der Launcher erkennt daran, welche Funktionen es gibt. */
        @JavascriptInterface
        fun ver(): String = if (trusted) "0.4" else ""

        /** Systemseite „App-Info“ einer App. */
        @JavascriptInterface
        fun appInfo(pkg: String) {
            if (!trusted || !pkgRegex.matches(pkg)) return
            try {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {
            }
        }

        /** Fragt Android, ob die App deinstalliert werden soll (der Nutzer bestätigt selbst). */
        @JavascriptInterface
        fun uninstall(pkg: String) {
            if (!trusted || !pkgRegex.matches(pkg) || pkg == packageName) return
            try {
                startActivity(
                    Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {
            }
        }

        /** Öffnet die Kamera. */
        @JavascriptInterface
        fun camera() {
            if (!trusted) return
            try {
                startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
            }
        }

        /** Öffnet die Galerie. */
        @JavascriptInterface
        fun gallery() {
            if (!trusted) return
            try {
                @Suppress("DEPRECATION")
                val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY)
                startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                try {
                    startActivity(
                        Intent(Intent.ACTION_VIEW).setType("image/*").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e2: Exception) {
                }
            }
        }

        /** Öffnet die Anrufliste. */
        @JavascriptInterface
        fun callLog() {
            if (!trusted) return
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW).setType(CallLog.Calls.CONTENT_TYPE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {
                try {
                    startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e2: Exception) {
                }
            }
        }

        /** Schnellseiten des Systems: "wifi", "volume", "bluetooth", "display", "airplane". */
        @JavascriptInterface
        fun panel(kind: String) {
            if (!trusted) return
            val action = when (kind) {
                "wifi" -> if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS
                "volume" -> if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_VOLUME else Settings.ACTION_SOUND_SETTINGS
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                "display" -> Settings.ACTION_DISPLAY_SETTINGS
                "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
                else -> return
            }
            try {
                startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
            }
        }

        /** Setzt ein Bild (Base64, JPEG oder PNG, ohne "data:"-Vorspann) als Hintergrund des Handys. true bei Erfolg. */
        @JavascriptInterface
        fun setWallpaper(b64: String): Boolean {
            if (!trusted || b64.length > 12_000_000) return false
            return try {
                val raw = Base64.decode(b64, Base64.DEFAULT)
                val bmp = BitmapFactory.decodeByteArray(raw, 0, raw.size) ?: return false
                WallpaperManager.getInstance(this@MainActivity).setBitmap(bmp)
                true
            } catch (e: Exception) {
                false
            }
        }

        /** Fragt ab, ob diese Hülle eine Funktion kennt (so erkennt der Launcher alte Hüllen). */
        @JavascriptInterface
        fun hasFeature(name: String): Boolean = trusted && name in setOf("ver", "appInfo", "uninstall", "camera", "gallery", "callLog", "panel", "setWallpaper", "pkgEvents")
    }
}
