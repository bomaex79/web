plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "de.bomaex.bmos"
    compileSdk = 34

    defaultConfig {
        applicationId = "de.bomaex.bmos"
        minSdk = 24
        targetSdk = 34
        versionCode = 3
        versionName = "0.3"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    // Fester Schlüssel: Nur so lässt sich eine neu gebaute APK über die alte installieren.
    // Gilt nur für diese private App. Für den Play Store einen eigenen, geheimen Schlüssel verwenden.
    signingConfigs {
        create("bmos") {
            storeFile = file("bmos.keystore")
            storePassword = "bmoslauncher"
            keyAlias = "bmos"
            keyPassword = "bmoslauncher"
        }
    }

    buildTypes {
        debug { signingConfig = signingConfigs.getByName("bmos") }
        release {
            signingConfig = signingConfigs.getByName("bmos")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // Offline-Spracherkennung für das Weckwort „Hey Bo“
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47")
}
