package de.bomaex.bmos

import android.annotation.SuppressLint
import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.ContactsContract
import android.provider.Settings
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.os.Message
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/**
 * BM OS: dünne Hülle um den Launcher auf https://www.bomaex.de/bmos/.
 * Alles, was im Launcher selbst passiert, wird per FTP aktualisiert, ohne neue APK.
 */
class MainActivity : Activity() {

    companion object {
        const val START_URL = "https://www.bomaex.de/bmos/"
        const val TRUSTED_HOST = "www.bomaex.de"
        const val TRUSTED_PATH = "/bmos"
    }

    private lateinit var web: WebView

    // Nur die eigene Launcher-Seite darf die Brücke BMNative benutzen.
    @Volatile
    private var trusted = false

    private fun isLauncherUrl(url: String?): Boolean {
        if (url == null) return false
        val u = Uri.parse(url)
        return u.scheme == "https" && u.host == TRUSTED_HOST &&
            (u.path ?: "").startsWith(TRUSTED_PATH)
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            allowFileAccess = false
            allowContentAccess = false
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
            mediaPlaybackRequiresUserGesture = true
        }
        web.setBackgroundColor(0xFF0A101D.toInt())
        web.addJavascriptInterface(Bridge(), "BMNative")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                if (isLauncherUrl(url)) return false
                openExternal(url)
                return true
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                trusted = isLauncherUrl(url)
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    trusted = false
                    view.loadUrl("file:///android_asset/offline.html")
                }
            }
        }

        // target="_blank" und window.open: im Standardbrowser öffnen, Launcher bleibt stehen
        web.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                val temp = WebView(this@MainActivity)
                temp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean {
                        openExternal(request.url.toString())
                        v.post { v.destroy() }
                        return true
                    }
                }
                (resultMsg.obj as WebView.WebViewTransport).webView = temp
                resultMsg.sendToTarget()
                return true
            }
        }

        if (savedInstanceState == null) web.loadUrl(START_URL) else web.restoreState(savedInstanceState)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    // Home-Taste, während der Launcher schon läuft
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) {
            web.evaluateJavascript("window.dispatchEvent(new Event('bmhome'))", null)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        web.evaluateJavascript("window.dispatchEvent(new Event('bmperm'))", null)
    }

    // Ein Launcher beendet sich nie: Zurück geht nur im Verlauf, sonst nichts
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onPause() {
        web.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    // ---------- Hilfsfunktionen ----------

    private fun openExternal(url: String) {
        try {
            if (url.startsWith("intent:")) {
                val intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                intent.addCategory(Intent.CATEGORY_BROWSABLE)
                intent.component = null
                intent.selector = null
                try {
                    startActivity(intent)
                } catch (e: ActivityNotFoundException) {
                    val fb = intent.getStringExtra("browser_fallback_url")
                    if (fb != null && fb.startsWith("https://")) openExternal(fb)
                }
                return
            }
            val scheme = Uri.parse(url).scheme
            if (scheme == "https" || scheme == "http" || scheme == "mailto" || scheme == "tel" || scheme == "market") {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        } catch (e: Exception) {
            // ungültige Adresse oder keine passende App: ignorieren
        }
    }

    private fun drawableToPng(d: Drawable, size: Int): String {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        d.setBounds(0, 0, size, size)
        d.draw(c)
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        bmp.recycle()
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    // ---------- Brücke zum Launcher (window.BMNative) ----------

    inner class Bridge {

        /** Liste aller startbaren Apps als JSON: [{n: Name, p: Paket, i: Symbol als data-URI}] */
        @JavascriptInterface
        fun apps(): String {
            if (!trusted) return "[]"
            val pm = packageManager
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(main, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { Triple(it.loadLabel(pm).toString(), it.activityInfo.packageName, it) }
                .distinctBy { it.second }
                .sortedBy { it.first.lowercase() }
            val arr = JSONArray()
            for ((name, pkg, info) in list) {
                val o = JSONObject()
                o.put("n", name)
                o.put("p", pkg)
                o.put("i", drawableToPng(info.loadIcon(pm), 96))
                arr.put(o)
            }
            return arr.toString()
        }

        /** Startet eine installierte App; ist sie nicht da, öffnet sich ihre Play-Store-Seite. */
        @JavascriptInterface
        fun launch(pkg: String) {
            if (!trusted || !Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$").matches(pkg)) return
            val intent = packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            } else {
                play(pkg)
            }
        }

        /** Öffnet den Play Store. */
        @JavascriptInterface
        fun playStore() {
            if (!trusted) return
            val intent = packageManager.getLaunchIntentForPackage("com.android.vending")
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            } else {
                openExternal("https://play.google.com/store")
            }
        }

        /** Öffnet die Play-Store-Seite eines Pakets. */
        @JavascriptInterface
        fun play(pkg: String) {
            if (!trusted || !Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$").matches(pkg)) return
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: ActivityNotFoundException) {
                openExternal("https://play.google.com/store/apps/details?id=$pkg")
            }
        }

        // ---------- Benachrichtigungen ----------

        /** Zähler pro App als JSON: {"com.whatsapp": 3, ...}. Braucht die Freigabe in den Systemeinstellungen. */
        @JavascriptInterface
        fun notifications(): String {
            if (!trusted) return "{}"
            val o = JSONObject()
            NotifService.counts.forEach { (k, v) -> o.put(k, v) }
            return o.toString()
        }

        @JavascriptInterface
        fun hasNotificationAccess(): Boolean {
            if (!trusted) return false
            val list = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            return list?.contains(packageName) == true
        }

        /** Öffnet die Systemseite, auf der der Nutzer BM OS den Zugriff auf Benachrichtigungen erlaubt. */
        @JavascriptInterface
        fun openNotificationSettings() {
            if (!trusted) return
            startActivity(
                Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }

        // ---------- Kontakte ----------

        @JavascriptInterface
        fun hasContacts(): Boolean =
            trusted && checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

        /** Fragt die Berechtigung an. Danach feuert im Launcher das Ereignis "bmperm". */
        @JavascriptInterface
        fun requestContacts() {
            if (!trusted) return
            runOnUiThread { requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 1) }
        }

        /** Kontakte als JSON: [{n: Name, t: Nummer, s: 1 wenn Favorit}], optional mit Suchtext. */
        @JavascriptInterface
        fun contacts(query: String): String {
            if (!hasContacts()) return "[]"
            val q = query.trim()
            val arr = JSONArray()
            val phone = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val sel = if (q.isEmpty()) null else "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
            val args = if (q.isEmpty()) null else arrayOf("%$q%")
            contentResolver.query(
                phone,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.STARRED
                ),
                sel, args,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} COLLATE LOCALIZED ASC"
            )?.use { c ->
                var n = 0
                while (c.moveToNext() && n < 300) {
                    val o = JSONObject()
                    o.put("n", c.getString(0) ?: "")
                    o.put("t", c.getString(1) ?: "")
                    o.put("s", if (c.getInt(2) == 1) 1 else 0)
                    arr.put(o)
                    n++
                }
            }
            return arr.toString()
        }

        private val phoneRegex = Regex("^[0-9+*#() \\-]{3,30}$")

        /** Öffnet die Telefon-App mit der Nummer (der Nutzer drückt selbst auf Anrufen). */
        @JavascriptInterface
        fun dial(number: String) {
            if (!trusted || !phoneRegex.matches(number)) return
            startActivity(
                Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }

        /** Öffnet die Nachrichten-App an die Nummer. */
        @JavascriptInterface
        fun sms(number: String) {
            if (!trusted || !phoneRegex.matches(number)) return
            startActivity(
                Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }

        // ---------- Gerät ----------

        /** {"level": 0-100, "charging": true/false} */
        @JavascriptInterface
        fun battery(): String {
            val o = JSONObject()
            if (!trusted) return o.toString()
            val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            o.put("level", if (level >= 0 && scale > 0) level * 100 / scale else -1)
            o.put("charging", status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL)
            return o.toString()
        }

        /** {"online": true/false, "type": "wifi" | "mobil" | "andere" | "keins"} */
        @JavascriptInterface
        fun network(): String {
            val o = JSONObject()
            if (!trusted) return o.toString()
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            val online = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
            o.put("online", online)
            o.put(
                "type", when {
                    caps == null -> "keins"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobil"
                    else -> "andere"
                }
            )
            return o.toString()
        }

        /** Taschenlampe an oder aus. Gibt true zurück, wenn es geklappt hat. */
        @JavascriptInterface
        fun torch(on: Boolean): Boolean {
            if (!trusted) return false
            return try {
                val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.firstOrNull {
                    cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                } ?: return false
                cm.setTorchMode(id, on)
                true
            } catch (e: Exception) {
                false
            }
        }

        /** Kurz vibrieren (1 bis 500 Millisekunden). */
        @JavascriptInterface
        fun vibrate(ms: Int) {
            if (!trusted) return
            val t = ms.coerceIn(1, 500).toLong()
            val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(t, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(t)
            }
        }

        /** Öffnet die Android-Einstellungen. */
        @JavascriptInterface
        fun openSettings() {
            if (!trusted) return
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
