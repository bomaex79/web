# BM OS Launcher (Android-Hülle)

Kleine Android-App, die den Launcher von **https://www.bomaex.de/bmos/** anzeigt.
Der Launcher selbst (HTML, Logos, Funktionen) liegt auf deinem FTP-Server. Änderungen dort
sind beim nächsten Start der App aktuell, ohne neue APK.

Die APK musst du nur neu bauen, wenn sich an dieser Hülle etwas ändert
(neue native Funktion, neue Berechtigung, App-Name oder App-Symbol).

## APK holen (ohne Android Studio)

1. Neues Repository auf GitHub anlegen und den **Inhalt dieses Ordners** hochladen
   (auch den versteckten Ordner `.github`).
2. Auf GitHub: **Actions** öffnen, **APK bauen**, **Run workflow**.
3. Nach etwa 3 bis 5 Minuten: den Lauf öffnen, unten unter **Artifacts** die Datei
   `BM-OS-Launcher` herunterladen (ZIP mit `BM-OS-Launcher.apk` darin).
4. Für einen Download-Link für andere: Tag `v0.1` anlegen. Die APK erscheint dann unter **Releases**.

## Installieren

1. APK auf dem Handy öffnen, Installation aus dieser Quelle erlauben.
2. Einstellungen, Apps, Standard-Apps, **Start-App**: **BM OS** wählen.

## Neue Version der Hülle

`versionCode` in `app/build.gradle.kts` erhöhen und neu bauen. Die APK ist immer mit dem
gleichen Schlüssel (`app/bmos.keystore`) signiert, daher lässt sie sich über die alte installieren.
Der Schlüssel liegt öffentlich im Repository. Das ist für eine private App in Ordnung.
Für den Play Store brauchst du einen eigenen, geheimen Schlüssel.

## Was die Hülle kann (window.BMNative)

Nur Seiten unter `https://www.bomaex.de/bmos/` dürfen diese Aufrufe benutzen.
Alle anderen Links öffnen sich im Standardbrowser.

| Aufruf | Wirkung |
| --- | --- |
| `apps()` | Liste aller startbaren Apps als JSON `[{n, p, i}]` |
| `launch(paket)` | App starten, sonst Play-Store-Seite |
| `playStore()`, `play(paket)` | Play Store öffnen, Seite eines Pakets |
| `notifications()` | Zähler pro App `{"paket": anzahl}` |
| `hasNotificationAccess()`, `openNotificationSettings()` | Zugriff prüfen, Systemseite zum Erlauben öffnen |
| `hasContacts()`, `requestContacts()` | Kontakte-Berechtigung prüfen und anfragen (danach Ereignis `bmperm`) |
| `contacts(suche)` | Kontakte als JSON `[{n, t, s}]`, `s` = Favorit |
| `dial(nummer)`, `sms(nummer)` | Telefon-App oder Nachrichten-App mit Nummer öffnen |
| `battery()` | `{level, charging}` |
| `network()` | `{online, type}` |
| `torch(an)` | Taschenlampe, gibt true/false zurück |
| `vibrate(ms)` | kurz vibrieren |
| `openSettings()` | Android-Einstellungen öffnen |

Ereignisse im Launcher: `bmhome` (Home-Taste gedrückt), `bmperm` (Berechtigungsfenster beantwortet).
Benachrichtigungen funktionieren erst, wenn der Nutzer BM OS einmal unter
Einstellungen, Benachrichtigungen, Zugriff auf Benachrichtigungen erlaubt hat.
