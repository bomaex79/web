package de.bomaex.bmos

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Weckwort „Hey Bo“. Läuft als Vordergrunddienst (mit sichtbarer Benachrichtigung) und hört
 * mit der Offline-Spracherkennung Vosk nur auf dieses eine Wort. Nichts wird aufgezeichnet oder gesendet.
 * Beim Treffer wird BM OS geöffnet und BM Alltag hört zu.
 */
class WakeService : Service() {

    companion object {
        const val ACTION_ASSIST = "de.bomaex.bmos.ASSIST"
        private const val CH_FG = "bmwake"
        private const val CH_ALERT = "bmwake_alert"
        private const val MODEL_NAME = "vosk-model-small-de-0.15"
        private const val MODEL_URL = "https://alphacephei.com/vosk/models/$MODEL_NAME.zip"
        private const val GRAMMAR = "[\"hey bo\", \"hey boh\", \"hey boo\", \"hey bow\", \"hey bou\", \"[unk]\"]"

        /** none | download | ready | error */
        @Volatile var status = "none"
        @Volatile var error = ""

        fun start(c: Context) {
            try {
                val i = Intent(c, WakeService::class.java)
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
            } catch (e: Exception) {
                status = "error"
                error = (e.message ?: e.javaClass.simpleName).take(120)
            }
        }

        fun stop(c: Context) {
            try { c.stopService(Intent(c, WakeService::class.java)) } catch (e: Exception) { }
            status = "none"
            error = ""
        }
    }

    @Volatile private var halt = false
    @Volatile private var running = false
    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            startFg()
        } catch (e: Exception) {
            status = "error"
            error = (e.message ?: "Dienst konnte nicht starten").take(120)
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) {
            running = true
            halt = false
            worker = Thread { loop() }.also { it.start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        halt = true
        super.onDestroy()
    }

    // ---------- Benachrichtigungen ----------

    private fun channels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_FG, "Hey Bo hört zu", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Hey Bo erkannt", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun builder(channel: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel) else @Suppress("DEPRECATION") Notification.Builder(this)

    private fun openPi(): PendingIntent {
        val i = Intent(this, MainActivity::class.java).setAction(ACTION_ASSIST)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        return PendingIntent.getActivity(this, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun startFg() {
        channels()
        val n = builder(CH_FG)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("BM OS hört auf „Hey Bo“")
            .setContentText("Tippen, um BM Alltag mit Mikrofon zu öffnen")
            .setContentIntent(openPi())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    // ---------- Weckwort erkannt ----------

    private fun wake() {
        val i = Intent(this, MainActivity::class.java).setAction(ACTION_ASSIST)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        try { startActivity(i) } catch (e: Exception) { }
        // Ohne „Über anderen Apps einblenden“ darf Android aus dem Hintergrund oft nichts öffnen: dann eine Benachrichtigung
        if (!Settings.canDrawOverlays(this)) {
            try {
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val pi = openPi()
                nm.notify(
                    2,
                    builder(CH_ALERT)
                        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                        .setContentTitle("Hey Bo")
                        .setContentText("Tippen, um zu sprechen")
                        .setContentIntent(pi)
                        .setFullScreenIntent(pi, true)
                        .setAutoCancel(true)
                        .build()
                )
            } catch (e: Exception) { }
        }
    }

    private fun hit(json: String): Boolean {
        return try {
            val o = JSONObject(json)
            val t = (if (o.has("partial")) o.getString("partial") else o.optString("text", "")).lowercase()
            Regex("hey\\s+bo").containsMatchIn(t)
        } catch (e: Exception) {
            false
        }
    }

    // ---------- Zuhör-Schleife ----------

    private fun loop() {
        var model: Model? = null
        var rec: Recognizer? = null
        var ar: AudioRecord? = null
        try {
            val dir = ensureModel()
            model = Model(dir.absolutePath)
            rec = Recognizer(model, 16000f, GRAMMAR)
            status = "ready"
            error = ""

            val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            ar = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 8192)
            )
            if (ar.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("Mikrofon nicht verfügbar")

            val buf = ShortArray(2048)
            var pauseUntil = 0L
            while (!halt) {
                if (System.currentTimeMillis() < pauseUntil) { Thread.sleep(300); continue }
                if (ar.recordingState != AudioRecord.RECORDSTATE_RECORDING) ar.startRecording()
                val n = ar.read(buf, 0, buf.size)
                if (n <= 0) { Thread.sleep(40); continue }
                val fin = rec.acceptWaveForm(buf, n)
                val txt = if (fin) rec.result else rec.partialResult
                if (hit(txt)) {
                    rec.reset()
                    // Mikrofon freigeben, damit die Spracherkennung der App es benutzen kann
                    try { ar.stop() } catch (e: Exception) { }
                    pauseUntil = System.currentTimeMillis() + 20000
                    wake()
                }
            }
        } catch (e: Exception) {
            status = "error"
            error = (e.message ?: e.javaClass.simpleName).take(120)
        } finally {
            try { ar?.stop() } catch (e: Exception) { }
            try { ar?.release() } catch (e: Exception) { }
            try { rec?.close() } catch (e: Exception) { }
            try { model?.close() } catch (e: Exception) { }
            running = false
            if (status != "error") status = "none"
            stopSelf()
        }
    }

    // ---------- Sprachmodell (einmalig laden, ca. 45 MB) ----------

    private fun ensureModel(): File {
        val dir = File(filesDir, MODEL_NAME)
        if (File(dir, "conf/model.conf").exists()) return dir
        status = "download"
        error = ""
        val zip = File(cacheDir, "model.zip")
        val c = URL(MODEL_URL).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        if (c.responseCode != 200) throw IllegalStateException("Download fehlgeschlagen (" + c.responseCode + ")")
        c.inputStream.use { inp -> zip.outputStream().use { out -> inp.copyTo(out) } }

        val tmp = File(filesDir, "$MODEL_NAME.tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()
        val base = tmp.canonicalPath + File.separator
        ZipInputStream(zip.inputStream().buffered()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val f = File(tmp, e.name)
                if (!f.canonicalPath.startsWith(base)) throw SecurityException("Ungültiges Archiv")
                if (e.isDirectory) {
                    f.mkdirs()
                } else {
                    f.parentFile?.mkdirs()
                    f.outputStream().use { z.copyTo(it) }
                }
                z.closeEntry()
                e = z.nextEntry
            }
        }
        zip.delete()
        val inner = File(tmp, MODEL_NAME)
        val src = if (inner.isDirectory) inner else tmp
        dir.deleteRecursively()
        if (!src.renameTo(dir)) throw IllegalStateException("Modell konnte nicht abgelegt werden")
        tmp.deleteRecursively()
        return dir
    }
}
