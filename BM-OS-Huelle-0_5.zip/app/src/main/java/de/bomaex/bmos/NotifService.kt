package de.bomaex.bmos

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Zählt die offenen Benachrichtigungen pro App, damit der Launcher Zähler an den Kacheln zeigen kann. */
class NotifService : NotificationListenerService() {

    companion object {
        @Volatile
        var counts: Map<String, Int> = emptyMap()
    }

    private fun refresh() {
        try {
            val m = HashMap<String, Int>()
            activeNotifications?.forEach { n ->
                if (n.isOngoing) return@forEach
                if (n.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return@forEach
                m[n.packageName] = (m[n.packageName] ?: 0) + 1
            }
            counts = m
        } catch (e: Exception) {
            // Dienst noch nicht bereit: ignorieren
        }
    }

    override fun onListenerConnected() = refresh()
    override fun onNotificationPosted(sbn: StatusBarNotification?) = refresh()
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = refresh()
}
