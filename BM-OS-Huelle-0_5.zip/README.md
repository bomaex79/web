# BM OS Launcher (Android-Hülle)

Kleine Android-App, die den Launcher von **https://www.bomaex.de/bmos/** anzeigt.
Der Launcher selbst (HTML, Logos, Funktionen) liegt auf deinem FTP-Server. Änderungen dort
sind beim nächsten Start der App aktuell, ohne neue APK.

Die APK musst du nur neu bauen, wenn sich an dieser Hülle etwas ändert
(neue native Funktion, neue Berechtigung, App-Name oder App-Symbol).

## APK holen (ohne Android Studio)

1. Neues Repository auf GitHub anlegen und den **Inhalt dieses Ordners** hochladen
   (auch den versteckten Ordner `.github`).
2. Auf GitHub: **Actions** öffnen, **APK bauen**, **Run workflow**.
3. Nach etwa 3 bis 5 Minuten: den Lauf öffnen, unten unter **Artifacts** die Datei
   `BM-OS-Launcher` herunterladen (ZIP mit `BM-OS-Launcher.apk` darin).
4. Für einen Download-Link für andere: Tag `v0.1` anlegen. Die APK erscheint dann unter **Releases**.

## Installieren

1. APK auf dem Handy öffnen, Installation aus dieser Quelle erlauben.
2. Einstellungen, Apps, Standard-Apps, **Start-App**: **BM OS** wählen.

## Neue Version der Hülle

`versionCode` in `app/build.gradle.kts` erhöhen und neu bauen. Die APK ist immer mit dem
gleichen Schlüssel (`app/bmos.keystore`) signiert, daher lässt sie sich über die alte installieren.
Der Schlüssel liegt öffentlich im Repository. Das ist für eine private App in Ordnung.
Für den Play Store brauchst du einen eigenen, geheimen Schlüssel.

## Was die Hülle kann (window.BMNative)

Nur Seiten unter `https://www.bomaex.de/bmos/` dürfen diese Aufrufe benutzen.
Alle anderen Links öffnen sich im Standardbrowser.

| Aufruf | Wirkung |
| --- | --- |
| `apps()` | Liste aller startbaren Apps als JSON `[{n, p, i}]` |
| `launch(paket)` | App starten, sonst Play-Store-Seite |
| `playStore()`, `play(paket)` | Play Store öffnen, Seite eines Pakets |
| `notifications()` | Zähler pro App `{"paket": anzahl}` |
| `hasNotificationAccess()`, `openNotificationSettings()` | Zugriff prüfen, Systemseite zum Erlauben öffnen |
| `hasContacts()`, `requestContacts()` | Kontakte-Berechtigung prüfen und anfragen (danach Ereignis `bmperm`) |
| `contacts(suche)` | Kontakte als JSON `[{n, t, s}]`, `s` = Favorit |
| `dial(nummer)`, `sms(nummer)` | Telefon-App oder Nachrichten-App mit Nummer öffnen |
| `battery()` | `{level, charging}` |
| `network()` | `{online, type}` |
| `torch(an)` | Taschenlampe, gibt true/false zurück |
| `vibrate(ms)` | kurz vibrieren |
| `openSettings()` | Android-Einstellungen öffnen |

Ereignisse im Launcher: `bmhome` (Home-Taste gedrückt), `bmperm` (Berechtigungsfenster beantwortet).
Benachrichtigungen funktionieren erst, wenn der Nutzer BM OS einmal unter
Einstellungen, Benachrichtigungen, Zugriff auf Benachrichtigungen erlaubt hat.


## Neu in 0.2 (versionCode 2)
- **Schneller zurück zum Launcher:** WebView-Prozess bleibt auch im Hintergrund wichtig, wird er doch beendet, baut sich die Ansicht selbst neu auf (kein Absturz). Beim ersten Start fragt Android einmal, ob BM OS von der Akku-Sparfunktion ausgenommen wird. **Bitte mit „Zulassen“ bestätigen.**
- **Zuletzt benutzte Apps und echte Symbole:** neue Aufrufe `hasUsageAccess()`, `openUsageSettings()`, `recents()`, `icon(paket)`. Der Launcher zeigt damit die Handy-Liste statt des Hinweises „neue BM OS App nötig“. Einmal unter Einstellungen > Nutzungsdaten-Zugriff erlauben.
- Tipp: Unter Einstellungen > Benachrichtigungen-Zugriff BM OS erlauben. Das hält die App zusätzlich im Speicher.


## Neu in 0.3 (versionCode 3)
- **Dateiauswahl funktioniert:** Eigenes Hintergrundbild (Einstellungen > Hintergrund > „Eigenes Bild wählen“) und der Import der Einstellungen öffnen jetzt die Android-Dateiauswahl (Fotos, Dateien, Google Drive).
- **Sprache in der Hülle:** Der Android-WebView hat keine eigene Spracherkennung. Neue Aufrufe `srStart(sprache)`, `srStop()`, `srCancel()` nutzen die Spracherkennung von Android. BM Alltag benutzt sie automatisch. Neue Berechtigung: Mikrofon (wird beim ersten Sprechen angefragt).
- **Assistent:** BM OS meldet sich als Assistenten-App an. Einstellungen > Apps > Standard-Apps > Digitaler Assistent: **BM OS** wählen (je nach Hersteller heißt die Seite etwas anders). Danach öffnet die Home-Taste (lange drücken) BM Alltag mit Mikrofon.
- **„Hey Bo“:** Neuer Dienst `WakeService`. Einschalten im Launcher unter Einstellungen > Sprachassistent. Beim ersten Mal lädt die App einmalig das kleine deutsche Vosk-Modell (ca. 45 MB, `vosk-model-small-de-0.15`) und hört danach offline auf das Weckwort. Es gibt eine dauerhafte Benachrichtigung, das ist bei Android Pflicht. Damit BM OS auch aus anderen Apps aufgeht: „Über anderen Apps einblenden“ erlauben (Knopf in den Einstellungen).
- Neue Aufrufe: `takeAssist()`, `wakeState()`, `wakeSet(an)`, `openOverlaySettings()`, `openAssistSettings()`. Neue Ereignisse: `bmassist`.
- Neue Bibliothek: `vosk-android` und `jna` (siehe `app/build.gradle.kts`). Die APK wird dadurch grösser (etwa 25 bis 30 MB).


## Neu in 0.4 (versionCode 4) – gehört zum Launcher 3.0
Neue Aufrufe in `window.BMNative`:

| Aufruf | Wirkung |
| --- | --- |
| `ver()` | Versionsname der Hülle ("0.4"); `hasFeature(name)` fragt einzelne Funktionen ab |
| `appInfo(paket)` | Systemseite „App-Info“ |
| `uninstall(paket)` | Android fragt, ob die App deinstalliert werden soll |
| `camera()`, `gallery()`, `callLog()` | Kamera, Galerie, Anrufliste öffnen |
| `panel(art)` | `wifi`, `volume`, `bluetooth`, `display`, `airplane`: Systemseite bzw. Schnellfenster |
| `setWallpaper(base64)` | Bild als Hintergrund des Handys setzen |

Neues Ereignis im Launcher: `bmpkg` (eine App wurde installiert, aktualisiert oder entfernt, die Liste lädt sich neu).
Neue Berechtigungen: `REQUEST_DELETE_PACKAGES` (Deinstallation, Android fragt immer selbst nach) und `SET_WALLPAPER`.
Hinweis: Doppeltippen zum Sperren ist nicht enthalten, das braucht den Bedienungshilfen-Zugriff.

**Neu bauen:** Dateien in dein GitHub-Repository hochladen (vorhandene ersetzen, auch `.github`), unter Actions „APK bauen“ starten.
Die APK ist mit demselben Schlüssel signiert und lässt sich über die alte 0.3 installieren.
