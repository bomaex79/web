# BM OS Launcher

Android-Launcher von Bo Maex™ Schneider (nativ, Kotlin, ohne Fremd-Bibliotheken).

## APK bei GitHub bauen
1. Neues Repository anlegen und den **gesamten Inhalt** dieses Ordners hochladen
   (wichtig: der versteckte Ordner `.github/workflows/build-apk.yml` muss dabei sein).
2. Reiter **Actions** öffnen → „BM OS APK bauen“ → **Run workflow** (läuft auch automatisch bei jedem Push).
3. Nach ca. 3–5 Minuten: Lauf anklicken → unten bei **Artifacts** „BM-OS-APK“ herunterladen → ZIP entpacken → APK auf dem Handy installieren.
4. Einstellungen → Apps → Standard-Apps → Start-App: **BM OS** wählen.

Voraussetzung: Android 8.0 oder neuer.
