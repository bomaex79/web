package de.bomaex.bmos

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class InfoActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#071A2E"))
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dpi(22f), dpi(40f), dpi(22f), dpi(36f))
        scroll.addView(box)

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_bm_logo)
        box.addView(logo, LinearLayout.LayoutParams(dpi(170f), dpi(124f)))

        box.addView(head("Impressum"))
        box.addView(body(
            "©Controlling\n" +
            "Bo Maex™ Schneider\n" +
            "Inh. Bo Maex Schneider\n" +
            "Salmstr. 15\n" +
            "52222 Stolberg\n\n" +
            "E-Mail: schneider@bomaex.de\n" +
            "Web: www.bomaex.de"
        ))

        box.addView(head("Urheberrecht"))
        box.addView(body("© Bo Maex Schneider.\nAlle Rechte vorbehalten."))

        box.addView(head("Datenschutz"))
        box.addView(body(
            "Der Schutz Ihrer Daten ist wichtig. BM OS ist ein Launcher, der alle Einstellungen " +
            "(Anordnung der Symbole, Ordner, Widgets, Design, Hintergrundbild) ausschließlich lokal auf Ihrem Gerät speichert. " +
            "BM OS enthält keine Werbung, keine Tracker und keine Analyse-Dienste und überträgt keine persönlichen Daten an Bo Maex Schneider oder Dritte.\n\n" +
            "Das gewählte Hintergrundbild wird nur im App-Speicher Ihres Geräts abgelegt und kann jederzeit in den Einstellungen entfernt werden.\n\n" +
            "Wetter: Für die Wetteranzeige werden der von Ihnen eingegebene Ortsname bzw. dessen Koordinaten an den Dienst open-meteo.com übertragen (Ortssuche und Wetterdaten). Der gewählte Ort wird nur lokal auf Ihrem Gerät gespeichert. Die Seite www.wetter.de öffnet sich nur, wenn Sie das Wetter-Widget antippen.\n\n" +
            "Internetzugriff: Verknüpfungen zu Webseiten " +
            "(z. B. bomaex.de, bmcity.de, bmfarm.de, bmalltag.de, bmmessenger.de, bo-maex.de) öffnen sich im Browser. " +
            "Auf diesen Webseiten gelten deren eigene Datenschutzbestimmungen.\n\n" +
            "Bei Fragen zum Datenschutz: schneider@bomaex.de"
        ))

        val site = Button(this)
        site.text = "Webseite Bo Maex™ · www.bomaex.de"
        site.setOnClickListener { open("https://www.bomaex.de") }
        box.addView(site, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dpi(18f) })

        val mail = Button(this)
        mail.text = "E-Mail schreiben"
        mail.setOnClickListener {
            try { startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:schneider@bomaex.de"))) } catch (e: Exception) { }
        }
        box.addView(mail, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        setContentView(scroll)
    }

    private fun open(url: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            i.setPackage("com.android.chrome")
            startActivity(i)
        } catch (e: Exception) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e2: Exception) { }
        }
    }

    private fun head(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(Color.parseColor("#3DA9ED"))
        tv.textSize = 20f
        tv.setPadding(0, dpi(22f), 0, dpi(6f))
        return tv
    }

    private fun body(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(Color.WHITE)
        tv.textSize = 15f
        tv.setLineSpacing(0f, 1.15f)
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#26FFFFFF"))
        bg.cornerRadius = dp(14f)
        tv.background = bg
        tv.setPadding(dpi(16f), dpi(14f), dpi(16f), dpi(14f))
        return tv
    }
}
