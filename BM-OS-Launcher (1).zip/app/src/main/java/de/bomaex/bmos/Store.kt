package de.bomaex.bmos

import android.content.Context
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

object T {
    const val APP = "APP"
    const val LINK = "LINK"
    const val CHROME = "CHROME"
    const val FOLDER = "FOLDER"
    const val CLOCK = "CLOCK"
    const val WEATHER = "WEATHER"
    const val SEARCH = "SEARCH"
    const val AWIDGET = "AWIDGET"
}

fun newId(): String = UUID.randomUUID().toString().take(8)

class Item(
    var id: String,
    var type: String,
    var label: String,
    var target: String = "",
    var fx: Float = 0f,
    var fy: Float = 0f,
    var scale: Float = 1f,
    var emoji: String = "",
    var color: Int = 0
) {
    val children = mutableListOf<Item>()

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("type", type)
        o.put("label", label)
        o.put("target", target)
        o.put("fx", fx.toDouble())
        o.put("fy", fy.toDouble())
        o.put("scale", scale.toDouble())
        o.put("emoji", emoji)
        o.put("color", color)
        if (children.isNotEmpty()) {
            val a = JSONArray()
            for (ch in children) a.put(ch.toJson())
            o.put("children", a)
        }
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): Item {
            val i = Item(
                o.getString("id"), o.getString("type"), o.optString("label"), o.optString("target"),
                o.optDouble("fx", 0.0).toFloat(), o.optDouble("fy", 0.0).toFloat(),
                o.optDouble("scale", 1.0).toFloat(), o.optString("emoji"), o.optInt("color", 0)
            )
            val a = o.optJSONArray("children")
            if (a != null) for (k in 0 until a.length()) i.children.add(fromJson(a.getJSONObject(k)))
            return i
        }
    }
}

class Store(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("bmos", Context.MODE_PRIVATE)

    var themeId: String
        get() = sp.getString("theme", "bm") ?: "bm"
        set(v) { sp.edit().putString("theme", v).apply() }

    var clockOn: Boolean
        get() = sp.getBoolean("clock", true)
        set(v) { sp.edit().putBoolean("clock", v).apply() }

    var labels: Boolean
        get() = sp.getBoolean("labels", true)
        set(v) { sp.edit().putBoolean("labels", v).apply() }

    var iconScale: Int
        get() = sp.getInt("iconScale", 100)
        set(v) { sp.edit().putInt("iconScale", v).apply() }

    var weatherName: String
        get() = sp.getString("wName", "") ?: ""
        set(v) { sp.edit().putString("wName", v).apply() }
    var weatherLat: Double
        get() = (sp.getString("wLat", "0") ?: "0").toDoubleOrNull() ?: 0.0
        set(v) { sp.edit().putString("wLat", v.toString()).apply() }
    var weatherLon: Double
        get() = (sp.getString("wLon", "0") ?: "0").toDoubleOrNull() ?: 0.0
        set(v) { sp.edit().putString("wLon", v.toString()).apply() }
    var weatherTemp: Float
        get() = sp.getFloat("wTemp", 0f)
        set(v) { sp.edit().putFloat("wTemp", v).apply() }
    var weatherMin: Float
        get() = sp.getFloat("wMin", 0f)
        set(v) { sp.edit().putFloat("wMin", v).apply() }
    var weatherMax: Float
        get() = sp.getFloat("wMax", 0f)
        set(v) { sp.edit().putFloat("wMax", v).apply() }
    var weatherCode: Int
        get() = sp.getInt("wCode", -1)
        set(v) { sp.edit().putInt("wCode", v).apply() }
    var weatherTime: Long
        get() = sp.getLong("wTime", 0L)
        set(v) { sp.edit().putLong("wTime", v).apply() }
    var weatherTried: Long
        get() = sp.getLong("wTried", 0L)
        set(v) { sp.edit().putLong("wTried", v).apply() }

    val wallpaperFile: File get() = File(ctx.filesDir, "wallpaper.jpg")

    val items: MutableList<Item> = mutableListOf()

    init { load() }

    fun load() {
        items.clear()
        val s = sp.getString("items", null)
        if (s == null) {
            items.addAll(defaults())
            save()
            return
        }
        try {
            val a = JSONArray(s)
            for (k in 0 until a.length()) items.add(Item.fromJson(a.getJSONObject(k)))
        } catch (e: Exception) {
            items.clear()
            items.addAll(defaults())
            save()
        }
    }

    fun save() {
        val a = JSONArray()
        for (i in items) a.put(i.toJson())
        sp.edit().putString("items", a.toString()).apply()
    }

    fun reset() {
        items.clear()
        items.addAll(defaults())
        save()
    }

    private fun link(id: String, label: String, url: String, emoji: String, color: String, fx: Float, fy: Float) =
        Item(id, T.LINK, label, url, fx, fy, 1f, emoji, Color.parseColor(color))

    fun defaults(): MutableList<Item> {
        val x = floatArrayOf(0.04f, 0.27f, 0.50f, 0.73f)
        val y1 = 0.34f
        val y2 = 0.51f
        return mutableListOf(
            Item("clock", T.CLOCK, "Uhr", "", 0.04f, 0.03f),
            Item("weather", T.WEATHER, "Wetter", "https://www.wetter.de", 0.58f, 0.04f),
            Item("search", T.SEARCH, "Suche", "", 0.04f, 0.21f),
            link("city", "BM City", "https://www.bmcity.de", "🏙️", "#287FC2", x[0], y1),
            link("farm", "BM Farm", "https://www.bmfarm.de", "🌾", "#3A9D4F", x[1], y1),
            link("alltag", "BM Alltag", "https://www.bmalltag.de", "📅", "#E08A2E", x[2], y1),
            link("messenger", "BM Messenger", "https://www.bmmessenger.de", "💬", "#2A8DE0", x[3], y1),
            link("musik", "BM Musik", "https://www.bomaex.de", "🎵", "#8E44AD", x[0], y2),
            link("podcast", "BM Podcast", "https://www.bomaex.de", "🎙️", "#C0392B", x[1], y2),
            link("community", "BM Community", "https://www.bo-maex.de", "👥", "#E84393", x[2], y2),
            Item("chrome", T.CHROME, "Chrome", "", x[3], y2, 1f, "🌐", Color.parseColor("#4285F4"))
        )
    }
}
