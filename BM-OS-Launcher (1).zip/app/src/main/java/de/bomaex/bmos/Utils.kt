package de.bomaex.bmos

import android.content.Context
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import kotlin.math.roundToInt

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density
fun Context.dpi(v: Float): Int = (v * resources.displayMetrics.density).roundToInt()

fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a shl 24)

object IconFactory {
    private fun lighten(c: Int, f: Float): Int {
        val r = Color.red(c) + ((255 - Color.red(c)) * f).toInt()
        val g = Color.green(c) + ((255 - Color.green(c)) * f).toInt()
        val b = Color.blue(c) + ((255 - Color.blue(c)) * f).toInt()
        return Color.rgb(r, g, b)
    }

    fun emoji(ctx: Context, emoji: String, color: Int, px: Int): Drawable {
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val r = px * 0.24f
        p.shader = LinearGradient(0f, 0f, px.toFloat(), px.toFloat(), lighten(color, 0.28f), color, Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(0f, 0f, px.toFloat(), px.toFloat()), r, r, p)
        p.shader = null
        val t = Paint(Paint.ANTI_ALIAS_FLAG)
        t.textSize = px * 0.54f
        t.textAlign = Paint.Align.CENTER
        val fm = t.fontMetrics
        c.drawText(emoji, px / 2f, px / 2f - (fm.ascent + fm.descent) / 2f, t)
        return BitmapDrawable(ctx.resources, bmp)
    }

    fun folder(ctx: Context, px: Int, card: Int, accent: Int, kids: List<Drawable>): Drawable {
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val r = px * 0.26f
        p.color = Color.argb(150, 20, 40, 70)
        c.drawRoundRect(RectF(0f, 0f, px.toFloat(), px.toFloat()), r, r, p)
        p.color = card
        c.drawRoundRect(RectF(0f, 0f, px.toFloat(), px.toFloat()), r, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = px * 0.025f
        p.color = withAlpha(accent, 0xAA)
        c.drawRoundRect(RectF(1f, 1f, px - 1f, px - 1f), r, r, p)
        val cell = px * 0.40f
        val gap = px * 0.07f
        val start = (px - (2 * cell + gap)) / 2f
        kids.take(4).forEachIndexed { i, d ->
            val col = i % 2
            val row = i / 2
            val l = (start + col * (cell + gap)).toInt()
            val t = (start + row * (cell + gap)).toInt()
            d.setBounds(l, t, l + cell.toInt(), t + cell.toInt())
            d.draw(c)
        }
        return BitmapDrawable(ctx.resources, bmp)
    }
}
