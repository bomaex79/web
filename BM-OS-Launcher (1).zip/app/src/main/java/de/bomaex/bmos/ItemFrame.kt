package de.bomaex.bmos

import android.content.Context
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.hypot

/** Rahmen um jedes Desktop-Element: Antippen, langes Drücken = Verschieben/Optionen. */
class ItemFrame(ctx: Context, val item: Item, private val cb: Callbacks) : FrameLayout(ctx) {

    interface Callbacks {
        fun onTap(f: ItemFrame)
        fun onDragStart(f: ItemFrame, rawX: Float, rawY: Float)
        fun onDragMove(f: ItemFrame, rawX: Float, rawY: Float)
        fun onDragEnd(f: ItemFrame, rawX: Float, rawY: Float, moved: Boolean)
    }

    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var longPressed = false
    private var moved = false

    private val longPress = Runnable {
        longPressed = true
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        parent?.requestDisallowInterceptTouchEvent(true)
        cb.onDragStart(this, downX, downY)
    }

    private fun far(e: MotionEvent) = hypot(e.rawX - downX, e.rawY - downY) > slop

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY
                longPressed = false; moved = false
                removeCallbacks(longPress)
                postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> if (!longPressed && far(e)) removeCallbacks(longPress)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> removeCallbacks(longPress)
        }
        return longPressed
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY
                longPressed = false; moved = false
                removeCallbacks(longPress)
                postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> {
                if (longPressed) {
                    if (far(e)) moved = true
                    cb.onDragMove(this, e.rawX, e.rawY)
                } else if (far(e)) removeCallbacks(longPress)
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longPress)
                if (longPressed) {
                    longPressed = false
                    cb.onDragEnd(this, e.rawX, e.rawY, moved)
                } else if (!far(e)) cb.onTap(this)
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPress)
                if (longPressed) {
                    longPressed = false
                    cb.onDragEnd(this, e.rawX, e.rawY, moved)
                }
            }
        }
        return true
    }
}
