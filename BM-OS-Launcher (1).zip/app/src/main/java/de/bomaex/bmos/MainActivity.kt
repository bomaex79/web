package de.bomaex.bmos

import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class AppEntry(val label: String, val pkg: String, val cls: String, val icon: Drawable) {
    val component: String get() = ComponentName(pkg, cls).flattenToString()
}

class MainActivity : Activity(), ItemFrame.Callbacks {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val REQ_BIND = 501
    private val REQ_CONFIGURE = 502

    private lateinit var store: Store
    private lateinit var tm: BmTheme
    private lateinit var root: FrameLayout
    private lateinit var wallpaper: ImageView
    private lateinit var content: FrameLayout
    private lateinit var desktop: DesktopLayout
    private lateinit var dock: LinearLayout
    private lateinit var trash: TextView
    private lateinit var drawer: LinearLayout
    private lateinit var drawerSearch: EditText
    private lateinit var drawerGrid: GridView
    private lateinit var adapter: AppAdapter
    private lateinit var host: AppWidgetHost
    private lateinit var awm: AppWidgetManager

    private val frames = mutableListOf<ItemFrame>()
    private var apps: List<AppEntry> = emptyList()
    private var shown: List<AppEntry> = emptyList()
    private var pendFx = 0.1f
    private var pendFy = 0.62f
    private var dragDx = 0f
    private var dragDy = 0f
    private var pendingId = -1
    private var pendingInfo: AppWidgetProviderInfo? = null
    private var wpKey = ""

    // ---------------------------------------------------------------- Lebenszyklus

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        tm = Themes.byId(store.themeId)
        awm = AppWidgetManager.getInstance(this)
        host = AppWidgetHost(this, 1024)
        buildUi()
    }

    override fun onStart() {
        super.onStart()
        try { host.startListening() } catch (e: Exception) { }
    }

    override fun onStop() {
        super.onStop()
        try { host.stopListening() } catch (e: Exception) { }
    }

    override fun onResume() {
        super.onResume()
        store = Store(this)
        applyTheme()
        desktop.post { render() }
        loadApps()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        closeDrawer()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (drawer.visibility == View.VISIBLE) closeDrawer()
        // Auf dem Startbildschirm bleibt der Launcher offen.
    }

    // ---------------------------------------------------------------- Aufbau der Oberfläche

    private fun buildUi() {
        root = FrameLayout(this)
        wallpaper = ImageView(this)
        wallpaper.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(wallpaper, FrameLayout.LayoutParams(MATCH, MATCH))

        content = FrameLayout(this)
        root.addView(content, FrameLayout.LayoutParams(MATCH, MATCH))

        desktop = DesktopLayout(this)
        val dlp = FrameLayout.LayoutParams(MATCH, MATCH)
        dlp.bottomMargin = dpi(108f)
        content.addView(desktop, dlp)
        desktop.onSwipeUp = { openDrawer(false) }
        desktop.onLongPressAt = { x, y ->
            val w = max(1, desktop.width).toFloat()
            val h = max(1, desktop.height).toFloat()
            pendFx = ((x - dpi(38f)) / w).coerceIn(0f, 0.8f)
            pendFy = ((y - dpi(40f)) / h).coerceIn(0f, 0.85f)
            showDesktopMenu()
        }

        dock = LinearLayout(this)
        dock.orientation = LinearLayout.HORIZONTAL
        dock.gravity = Gravity.CENTER
        dock.setPadding(dpi(10f), dpi(8f), dpi(10f), dpi(8f))
        dock.addView(dockButton("📞", "#2E9E5B", "Telefon") { safeStart(Intent(Intent.ACTION_DIAL)) })
        dock.addView(dockButton("📷", "#6C7A89", "Kamera") { safeStart(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) })
        dock.addView(dockButton("🗂️", "#3DA9ED", "Apps") { openDrawer(false) })
        dock.addView(dockButton("⚙️", "#5D6D7E", "Einstellungen") { startActivity(Intent(this, SettingsActivity::class.java)) })
        val klp = FrameLayout.LayoutParams(WRAP, dpi(76f), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        klp.bottomMargin = dpi(16f)
        content.addView(dock, klp)

        trash = TextView(this)
        trash.text = "🗑  Zum Entfernen hier loslassen"
        trash.gravity = Gravity.CENTER
        trash.setTextColor(Color.WHITE)
        trash.textSize = 16f
        trash.setBackgroundColor(Color.argb(210, 190, 40, 50))
        trash.visibility = View.GONE
        content.addView(trash, FrameLayout.LayoutParams(MATCH, dpi(56f), Gravity.TOP))

        buildDrawer()
        root.addView(drawer, FrameLayout.LayoutParams(MATCH, MATCH))

        setContentView(root)
        root.setOnApplyWindowInsetsListener { _, ins ->
            @Suppress("DEPRECATION")
            val top = ins.systemWindowInsetTop
            @Suppress("DEPRECATION")
            val bottom = ins.systemWindowInsetBottom
            content.setPadding(0, top, 0, bottom)
            drawer.setPadding(0, top + dpi(8f), 0, bottom)
            ins
        }
        root.requestApplyInsets()
    }

    private fun dockButton(emoji: String, color: String, label: String, action: () -> Unit): View {
        val v = ImageView(this)
        v.setImageDrawable(IconFactory.emoji(this, emoji, Color.parseColor(color), dpi(52f)))
        v.contentDescription = label
        v.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(dpi(52f), dpi(52f))
        lp.marginStart = dpi(8f)
        lp.marginEnd = dpi(8f)
        v.layoutParams = lp
        return v
    }

    private fun buildDrawer() {
        drawer = LinearLayout(this)
        drawer.orientation = LinearLayout.VERTICAL
        drawer.visibility = View.GONE
        drawer.isClickable = true

        drawerSearch = EditText(this)
        drawerSearch.hint = "Apps oder Web durchsuchen"
        drawerSearch.setSingleLine(true)
        drawerSearch.inputType = InputType.TYPE_CLASS_TEXT
        drawerSearch.imeOptions = EditorInfo.IME_ACTION_SEARCH
        drawerSearch.textSize = 16f
        drawerSearch.setPadding(dpi(20f), dpi(12f), dpi(20f), dpi(12f))
        val slp = LinearLayout.LayoutParams(MATCH, WRAP)
        slp.setMargins(dpi(16f), dpi(8f), dpi(16f), dpi(8f))
        drawer.addView(drawerSearch, slp)

        drawerSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                filterApps(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        drawerSearch.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                val q = v.text.toString().trim()
                if (shown.size == 1) {
                    launchApp(shown[0].component)
                    closeDrawer()
                } else if (q.isNotEmpty()) {
                    openUrl("https://www.google.com/search?q=" + Uri.encode(q))
                    closeDrawer()
                }
                true
            } else false
        }

        drawerGrid = GridView(this)
        drawerGrid.numColumns = 4
        drawerGrid.verticalSpacing = dpi(10f)
        drawerGrid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        drawerGrid.setPadding(dpi(8f), dpi(8f), dpi(8f), dpi(8f))
        drawerGrid.clipToPadding = false
        drawerGrid.setSelector(ColorDrawable(Color.TRANSPARENT))
        adapter = AppAdapter()
        drawerGrid.adapter = adapter
        drawerGrid.setOnItemClickListener { _, _, pos, _ ->
            if (pos < shown.size) {
                launchApp(shown[pos].component)
                closeDrawer()
            }
        }
        drawerGrid.setOnItemLongClickListener { _, _, pos, _ ->
            if (pos < shown.size) appMenu(shown[pos])
            true
        }
        drawer.addView(drawerGrid, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    private fun card(color: Int, radiusDp: Float): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp)
        g.setStroke(dpi(1f), withAlpha(tm.accent, 0x55))
        return g
    }

    private fun applyTheme() {
        tm = Themes.byId(store.themeId)
        val wf = store.wallpaperFile
        val key = tm.id + "|" + (if (wf.exists()) wf.lastModified() else 0L)
        if (key != wpKey) {
            wpKey = key
            var set = false
            if (wf.exists()) {
                try {
                    val b = BitmapFactory.decodeFile(wf.absolutePath)
                    if (b != null) {
                        wallpaper.setImageBitmap(b)
                        set = true
                    }
                } catch (e: Throwable) { }
            }
            if (!set) wallpaper.setImageDrawable(GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, tm.bg))
        }
        dock.background = card(tm.card, 32f)
        drawer.setBackgroundColor(withAlpha(tm.bg[1], 0xF2))
        drawerSearch.setTextColor(tm.text)
        drawerSearch.setHintTextColor(withAlpha(tm.text, 0x99))
        drawerSearch.background = card(tm.card, 26f)

        @Suppress("DEPRECATION")
        var flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        if (tm.light) {
            @Suppress("DEPRECATION")
            flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) {
                @Suppress("DEPRECATION")
                flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
        }
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = flags
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        adapter.notifyDataSetChanged()
    }

    // ---------------------------------------------------------------- Desktop zeichnen

    private fun appExists(target: String): Boolean {
        val cn = ComponentName.unflattenFromString(target) ?: return false
        return try { packageManager.getActivityInfo(cn, 0); true } catch (e: Exception) { false }
    }

    private fun sizeOf(item: Item, deskW: Int): Pair<Int, Int>? {
        val g = store.iconScale / 100f
        val s = item.scale
        val maxW = deskW - dpi(8f)
        return when (item.type) {
            T.APP, T.LINK, T.CHROME, T.FOLDER ->
                Pair(min(maxW, dpi(76f * s * g)), dpi(92f * s * g))
            T.CLOCK -> Pair(min(maxW, dpi(190f * s)), dpi(96f * s))
            T.WEATHER -> Pair(min(maxW, dpi(150f * s)), dpi(96f * s))
            T.SEARCH -> Pair(min(maxW, dpi(300f * s)), dpi(52f * s))
            T.AWIDGET -> {
                val id = item.target.toIntOrNull() ?: return null
                val info = awm.getAppWidgetInfo(id) ?: return null
                Pair(min(maxW, (max(info.minWidth, dpi(110f)) * s).roundToInt()),
                    (max(info.minHeight, dpi(70f)) * s).roundToInt())
            }
            else -> null
        }
    }

    private fun render() {
        if (isFinishing) return
        val w = desktop.width
        val h = desktop.height
        if (w == 0 || h == 0) {
            desktop.post { render() }
            return
        }
        desktop.removeAllViews()
        frames.clear()
        val dead = mutableListOf<Item>()
        for (item in store.items) {
            if (item.type == T.CLOCK && !store.clockOn) continue
            if (item.type == T.APP && !appExists(item.target)) continue
            val size = sizeOf(item, w)
            if (size == null) { dead.add(item); continue }
            val view = buildContent(item, size.first, size.second)
            if (view == null) { dead.add(item); continue }
            val frame = ItemFrame(this, item, this)
            frame.addView(view, FrameLayout.LayoutParams(MATCH, MATCH))
            desktop.addView(frame, FrameLayout.LayoutParams(size.first, size.second))
            frame.x = (item.fx * w).coerceIn(0f, max(0f, (w - size.first).toFloat()))
            frame.y = (item.fy * h).coerceIn(0f, max(0f, (h - size.second).toFloat()))
            frames.add(frame)
        }
        if (dead.isNotEmpty()) {
            for (d in dead) if (d.type == T.AWIDGET) d.target.toIntOrNull()?.let { host.deleteAppWidgetId(it) }
            store.items.removeAll(dead)
            store.save()
        }
    }

    private fun iconFor(item: Item, px: Int): Drawable {
        return when (item.type) {
            T.APP -> try {
                packageManager.getActivityIcon(ComponentName.unflattenFromString(item.target)!!)
            } catch (e: Exception) {
                IconFactory.emoji(this, "📱", Color.GRAY, px)
            }
            T.FOLDER -> IconFactory.folder(this, px, tm.card, tm.accent, item.children.take(4).map { iconFor(it, px / 2) })
            else -> IconFactory.emoji(this, item.emoji.ifEmpty { "🔗" }, if (item.color == 0) tm.accent else item.color, px)
        }
    }

    private fun label(text: String, sizeSp: Float): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(tm.text)
        tv.textSize = sizeSp
        tv.maxLines = 1
        tv.ellipsize = TextUtils.TruncateAt.END
        tv.gravity = Gravity.CENTER
        tv.setShadowLayer(3f, 0f, 1f, Color.argb(160, 0, 0, 0))
        return tv
    }

    private fun buildContent(item: Item, w: Int, h: Int): View? {
        val s = item.scale
        val g = store.iconScale / 100f
        when (item.type) {
            T.APP, T.LINK, T.CHROME, T.FOLDER -> {
                val box = LinearLayout(this)
                box.orientation = LinearLayout.VERTICAL
                box.gravity = Gravity.CENTER_HORIZONTAL
                box.setPadding(0, dpi(4f), 0, 0)
                val px = dpi(56f * s * g)
                val img = ImageView(this)
                img.setImageDrawable(iconFor(item, px))
                box.addView(img, LinearLayout.LayoutParams(px, px))
                if (store.labels) {
                    val tv = label(item.label, (11f * s * g).coerceIn(9f, 18f))
                    box.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP))
                }
                return box
            }
            T.CLOCK -> {
                val box = LinearLayout(this)
                box.orientation = LinearLayout.VERTICAL
                box.gravity = Gravity.CENTER_VERTICAL
                val time = TextClock(this)
                time.format24Hour = "HH:mm"
                time.format12Hour = "HH:mm"
                time.textSize = 46f * s
                time.setTextColor(tm.text)
                time.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                time.includeFontPadding = false
                time.setShadowLayer(4f, 0f, 1f, Color.argb(140, 0, 0, 0))
                val date = TextClock(this)
                date.format24Hour = "EEEE, d. MMMM"
                date.format12Hour = "EEEE, d. MMMM"
                date.textSize = 13f * s
                date.setTextColor(withAlpha(tm.text, 0xDD))
                date.setShadowLayer(3f, 0f, 1f, Color.argb(140, 0, 0, 0))
                box.addView(time, LinearLayout.LayoutParams(WRAP, WRAP))
                box.addView(date, LinearLayout.LayoutParams(WRAP, WRAP))
                return box
            }
            T.WEATHER -> {
                val box = LinearLayout(this)
                box.orientation = LinearLayout.VERTICAL
                box.gravity = Gravity.CENTER
                box.setPadding(dpi(6f), dpi(4f), dpi(6f), dpi(4f))
                box.background = card(tm.card, 22f * s)
                if (store.weatherName.isEmpty()) {
                    val ic = TextView(this)
                    ic.text = "📍"
                    ic.textSize = 24f * s
                    ic.gravity = Gravity.CENTER
                    val t1 = label("Ort wählen", 14f * s)
                    t1.typeface = Typeface.DEFAULT_BOLD
                    val t2 = label("Tippen zum Einstellen", 10f * s)
                    t2.setTextColor(tm.accent)
                    box.addView(ic, LinearLayout.LayoutParams(WRAP, WRAP))
                    box.addView(t1, LinearLayout.LayoutParams(WRAP, WRAP))
                    box.addView(t2, LinearLayout.LayoutParams(WRAP, WRAP))
                } else {
                    val has = store.weatherCode >= 0
                    val d = Weather.describe(store.weatherCode)
                    val row = LinearLayout(this)
                    row.orientation = LinearLayout.HORIZONTAL
                    row.gravity = Gravity.CENTER
                    val ic = TextView(this)
                    ic.text = if (has) d.first else "🌡️"
                    ic.textSize = 26f * s
                    val tt = TextView(this)
                    tt.text = if (has) store.weatherTemp.roundToInt().toString() + "°" else "…"
                    tt.textSize = 26f * s
                    tt.typeface = Typeface.DEFAULT_BOLD
                    tt.setTextColor(tm.text)
                    tt.setPadding(dpi(6f), 0, 0, 0)
                    row.addView(ic, LinearLayout.LayoutParams(WRAP, WRAP))
                    row.addView(tt, LinearLayout.LayoutParams(WRAP, WRAP))
                    val city = label(store.weatherName, 12f * s)
                    city.typeface = Typeface.DEFAULT_BOLD
                    val sub = label(
                        if (has) d.second + " · " + store.weatherMax.roundToInt() + "°/" + store.weatherMin.roundToInt() + "°" else "lädt …",
                        10f * s
                    )
                    sub.setTextColor(tm.accent)
                    box.addView(row, LinearLayout.LayoutParams(WRAP, WRAP))
                    box.addView(city, LinearLayout.LayoutParams(MATCH, WRAP))
                    box.addView(sub, LinearLayout.LayoutParams(MATCH, WRAP))
                    Weather.refreshIfStale(store) { runOnUiThread { renderSoon() } }
                }
                return box
            }
            T.SEARCH -> {
                val tv = TextView(this)
                tv.text = "🔍  Apps & Web durchsuchen"
                tv.setTextColor(withAlpha(tm.text, 0xCC))
                tv.textSize = 15f * s
                tv.gravity = Gravity.CENTER_VERTICAL
                tv.setPadding(dpi(20f * s), 0, dpi(12f), 0)
                tv.maxLines = 1
                tv.ellipsize = TextUtils.TruncateAt.END
                tv.background = card(tm.card, 40f)
                return tv
            }
            T.AWIDGET -> {
                val id = item.target.toIntOrNull() ?: return null
                val info = awm.getAppWidgetInfo(id) ?: return null
                val hv = host.createView(this, id, info)
                val wDp = (w / resources.displayMetrics.density).roundToInt()
                val hDp = (h / resources.displayMetrics.density).roundToInt()
                try { hv.updateAppWidgetSize(null, wDp, hDp, wDp, hDp) } catch (e: Exception) { }
                return hv
            }
        }
        return null
    }

    // ---------------------------------------------------------------- Antippen und Verschieben

    override fun onTap(f: ItemFrame) {
        val item = f.item
        when (item.type) {
            T.APP, T.LINK, T.CHROME -> activate(item)
            T.FOLDER -> openFolder(item)
            T.WEATHER -> if (store.weatherName.isEmpty()) Weather.pickLocation(this, store) { renderSoon() } else openWeather()
            T.SEARCH -> openDrawer(true)
            T.CLOCK -> safeStart(Intent(AlarmClock.ACTION_SHOW_ALARMS))
            else -> {}
        }
    }

    override fun onDragStart(f: ItemFrame, rawX: Float, rawY: Float) {
        dragDx = f.x - rawX
        dragDy = f.y - rawY
        f.bringToFront()
        f.animate().scaleX(1.08f).scaleY(1.08f).alpha(0.85f).setDuration(120).start()
        trash.visibility = View.VISIBLE
        trash.bringToFront()
    }

    override fun onDragMove(f: ItemFrame, rawX: Float, rawY: Float) {
        f.x = rawX + dragDx
        f.y = rawY + dragDy
    }

    private fun overTrash(rawY: Float): Boolean {
        val loc = IntArray(2)
        trash.getLocationOnScreen(loc)
        return rawY < loc[1] + trash.height
    }

    override fun onDragEnd(f: ItemFrame, rawX: Float, rawY: Float, moved: Boolean) {
        trash.visibility = View.GONE
        f.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(120).start()
        val item = f.item
        if (!moved) {
            showOptions(item)
            return
        }
        if (overTrash(rawY)) {
            removeItem(item)
            renderSoon()
            return
        }
        val iconTypes = setOf(T.APP, T.LINK, T.CHROME)
        val cx = f.x + f.width / 2f
        val cy = f.y + f.height / 2f
        val target = frames.firstOrNull { fr ->
            fr !== f && cx >= fr.x && cx <= fr.x + fr.width && cy >= fr.y && cy <= fr.y + fr.height &&
                (fr.item.type == T.FOLDER || fr.item.type in iconTypes)
        }
        if (target != null && item.type in iconTypes) {
            if (target.item.type == T.FOLDER) {
                store.items.remove(item)
                target.item.children.add(item)
            } else {
                val folder = Item(newId(), T.FOLDER, "Ordner", "", target.item.fx, target.item.fy, target.item.scale)
                store.items.remove(item)
                val idx = store.items.indexOf(target.item)
                if (idx >= 0) store.items[idx] = folder
                else store.items.add(folder)
                folder.children.add(target.item)
                folder.children.add(item)
            }
            store.save()
            renderSoon()
            return
        }
        val w = max(1, desktop.width).toFloat()
        val h = max(1, desktop.height).toFloat()
        val nx = f.x.coerceIn(0f, max(0f, w - f.width))
        val ny = f.y.coerceIn(0f, max(0f, h - f.height))
        f.x = nx
        f.y = ny
        item.fx = nx / w
        item.fy = ny / h
        store.save()
    }

    private fun renderSoon() {
        desktop.post { render() }
    }

    private fun removeItem(item: Item) {
        when (item.type) {
            T.CLOCK -> store.clockOn = false
            T.FOLDER -> dissolveFolder(item)
            T.AWIDGET -> {
                item.target.toIntOrNull()?.let { host.deleteAppWidgetId(it) }
                store.items.remove(item)
            }
            else -> store.items.remove(item)
        }
        store.save()
    }

    private fun dissolveFolder(folder: Item) {
        var i = 0
        for (ch in folder.children) {
            ch.fx = (folder.fx + 0.22f * (i % 3)).coerceAtMost(0.75f)
            ch.fy = (folder.fy + 0.16f * (i / 3)).coerceAtMost(0.8f)
            store.items.add(ch)
            i++
        }
        store.items.remove(folder)
    }

    // ---------------------------------------------------------------- Dialoge

    private fun choose(title: String, entries: List<Pair<String, () -> Unit>>) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(entries.map { it.first }.toTypedArray()) { _, i -> entries[i].second() }
            .show()
    }

    private fun showOptions(item: Item) {
        val e = mutableListOf<Pair<String, () -> Unit>>()
        if (item.type == T.FOLDER) e.add("Öffnen" to { openFolder(item) })
        e.add("Größe ändern" to { showSize(item) })
        if (item.type == T.WEATHER) {
            e.add("Wetter-Ort ändern" to { Weather.pickLocation(this, store) { renderSoon() } })
            e.add("Jetzt aktualisieren" to { Weather.refreshIfStale(store, true) { runOnUiThread { renderSoon() } } })
            e.add("wetter.de öffnen" to { openWeather() })
        }
        if (item.type == T.APP || item.type == T.LINK || item.type == T.FOLDER) {
            e.add("Umbenennen" to { showRename(item) })
        }
        when (item.type) {
            T.CLOCK -> e.add("Uhr ausschalten" to { removeItem(item); renderSoon() })
            T.FOLDER -> e.add("Ordner auflösen" to { removeItem(item); renderSoon() })
            else -> e.add("Entfernen" to { removeItem(item); renderSoon() })
        }
        choose(if (item.label.isBlank()) "Optionen" else item.label, e)
    }

    private fun showSize(item: Item) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dpi(24f), dpi(16f), dpi(24f), dpi(8f))
        val tv = TextView(this)
        tv.setTextColor(Color.WHITE)
        tv.textSize = 16f
        tv.text = "Größe: " + (item.scale * 100).roundToInt() + " %"
        val sb = SeekBar(this)
        sb.max = 200 // 50 % bis 250 %
        sb.progress = ((item.scale * 100) - 50).roundToInt().coerceIn(0, 200)
        box.addView(tv)
        box.addView(sb, LinearLayout.LayoutParams(MATCH, WRAP))
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                item.scale = (p + 50) / 100f
                tv.text = "Größe: " + (p + 50) + " %"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { renderSoon() }
        })
        AlertDialog.Builder(this)
            .setTitle("Größe ändern")
            .setView(box)
            .setPositiveButton("OK", null)
            .setOnDismissListener { store.save(); renderSoon() }
            .show()
    }

    private fun showRename(item: Item) {
        val et = EditText(this)
        et.setText(item.label)
        et.setSingleLine(true)
        et.setSelection(et.text.length)
        AlertDialog.Builder(this)
            .setTitle("Umbenennen")
            .setView(et)
            .setPositiveButton("OK") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) {
                    item.label = t
                    store.save()
                    renderSoon()
                }
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun showDesktopMenu() {
        choose("Desktop", listOf(
            "Widget hinzufügen" to { showAddWidget() },
            "Ordner erstellen" to { addItem(Item(newId(), T.FOLDER, "Ordner", "", pendFx, pendFy)) },
            "Webseite als Symbol hinzufügen" to { showAddLink() },
            "Hintergrundbild ändern" to {
                startActivity(Intent(this, SettingsActivity::class.java).putExtra("pick", true))
            },
            "Einstellungen" to { startActivity(Intent(this, SettingsActivity::class.java)) }
        ))
    }

    private fun addItem(item: Item) {
        store.items.add(item)
        store.save()
        renderSoon()
    }

    private fun showAddWidget() {
        choose("Widget hinzufügen", listOf(
            "Uhr" to {
                store.clockOn = true
                if (store.items.none { it.type == T.CLOCK }) {
                    addItem(Item(newId(), T.CLOCK, "Uhr", "", pendFx, pendFy))
                } else renderSoon()
            },
            "Wetter (wetter.de)" to { addItem(Item(newId(), T.WEATHER, "Wetter", "https://www.wetter.de", pendFx, pendFy)) },
            "Suchleiste" to { addItem(Item(newId(), T.SEARCH, "Suche", "", pendFx, pendFy)) },
            "Android-Widget wählen …" to { pickAndroidWidget() }
        ))
    }

    private fun showAddLink() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dpi(20f), dpi(8f), dpi(20f), 0)
        val name = EditText(this)
        name.hint = "Name"
        name.setSingleLine(true)
        val url = EditText(this)
        url.hint = "Adresse, z. B. www.bomaex.de"
        url.setSingleLine(true)
        url.inputType = InputType.TYPE_TEXT_VARIATION_URI
        box.addView(name)
        box.addView(url)
        AlertDialog.Builder(this)
            .setTitle("Webseite hinzufügen")
            .setView(box)
            .setPositiveButton("Hinzufügen") { _, _ ->
                var u = url.text.toString().trim()
                if (u.isNotEmpty()) {
                    if (!u.startsWith("http")) u = "https://$u"
                    val n = name.text.toString().trim().ifEmpty { u.removePrefix("https://").removePrefix("www.") }
                    addItem(Item(newId(), T.LINK, n, u, pendFx, pendFy, 1f, "🔗", tm.accent))
                }
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    // ---------------------------------------------------------------- Android-Widgets

    private fun pickAndroidWidget() {
        val list = try { awm.installedProviders } catch (e: Exception) { emptyList<AppWidgetProviderInfo>() }
        if (list.isEmpty()) {
            toast("Keine Widgets gefunden")
            return
        }
        val sorted = list.sortedBy { it.loadLabel(packageManager).lowercase() }
        val names = sorted.map { it.loadLabel(packageManager) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Android-Widget wählen")
            .setItems(names) { _, i -> bindWidget(sorted[i]) }
            .show()
    }

    private fun bindWidget(p: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId()
        pendingId = id
        pendingInfo = p
        if (awm.bindAppWidgetIdIfAllowed(id, p.provider)) {
            configureOrAdd(id, p)
        } else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider)
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(i, REQ_BIND)
            } catch (e: Exception) {
                host.deleteAppWidgetId(id)
                toast("Widget kann nicht hinzugefügt werden")
            }
        }
    }

    private fun configureOrAdd(id: Int, p: AppWidgetProviderInfo) {
        if (p.configure != null) {
            try {
                host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIGURE, null)
            } catch (e: Exception) {
                addWidgetItem(id)
            }
        } else addWidgetItem(id)
    }

    private fun addWidgetItem(id: Int) {
        addItem(Item(newId(), T.AWIDGET, "Widget", id.toString(), pendFx, pendFy))
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val info = pendingInfo
        when (requestCode) {
            REQ_BIND -> if (resultCode == RESULT_OK && info != null) configureOrAdd(pendingId, info)
                        else host.deleteAppWidgetId(pendingId)
            REQ_CONFIGURE -> if (resultCode == RESULT_OK) addWidgetItem(pendingId)
                             else host.deleteAppWidgetId(pendingId)
        }
    }

    // ---------------------------------------------------------------- Ordner

    private fun openFolder(folder: Item) {
        val grid = GridLayout(this)
        grid.columnCount = 4
        val scroll = ScrollView(this)
        scroll.addView(grid)
        scroll.setPadding(dpi(8f), dpi(8f), dpi(8f), dpi(8f))
        val dlg = AlertDialog.Builder(this)
            .setTitle(folder.label)
            .setView(scroll)
            .setPositiveButton("Schließen", null)
            .setNeutralButton("Umbenennen") { _, _ -> showRename(folder) }
            .create()
        if (folder.children.isEmpty()) {
            val tv = TextView(this)
            tv.text = "Leer – ziehe Symbole auf den Ordner."
            tv.setTextColor(Color.WHITE)
            tv.setPadding(dpi(16f), dpi(16f), dpi(16f), dpi(16f))
            grid.addView(tv)
        }
        for (ch in folder.children.toList()) {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.gravity = Gravity.CENTER_HORIZONTAL
            box.setPadding(0, dpi(6f), 0, dpi(6f))
            val img = ImageView(this)
            img.setImageDrawable(iconFor(ch, dpi(52f)))
            box.addView(img, LinearLayout.LayoutParams(dpi(52f), dpi(52f)))
            val tv = TextView(this)
            tv.text = ch.label
            tv.setTextColor(Color.WHITE)
            tv.textSize = 11f
            tv.maxLines = 1
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.gravity = Gravity.CENTER
            box.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP))
            box.setOnClickListener { dlg.dismiss(); activate(ch) }
            box.setOnLongClickListener {
                dlg.dismiss()
                choose(ch.label, listOf(
                    "Auf den Desktop legen" to {
                        folder.children.remove(ch)
                        ch.fx = pendFx; ch.fy = pendFy
                        store.items.add(ch)
                        store.save(); renderSoon()
                    },
                    "Aus Ordner entfernen" to {
                        folder.children.remove(ch)
                        store.save(); renderSoon()
                    }
                ))
                true
            }
            val lp = GridLayout.LayoutParams()
            lp.width = dpi(72f)
            lp.height = WRAP
            grid.addView(box, lp)
        }
        dlg.show()
    }

    // ---------------------------------------------------------------- Starten

    private fun activate(item: Item) {
        when (item.type) {
            T.APP -> launchApp(item.target)
            T.LINK -> openUrl(item.target)
            T.CHROME -> openChrome()
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun safeStart(i: Intent) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            toast("Keine passende App gefunden")
        }
    }

    private fun launchApp(target: String) {
        val cn = ComponentName.unflattenFromString(target) ?: return
        val i = Intent(Intent.ACTION_MAIN)
        i.addCategory(Intent.CATEGORY_LAUNCHER)
        i.component = cn
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try { startActivity(i) } catch (e: Exception) { toast("App nicht gefunden") }
    }

    private fun openUrl(url: String) {
        val uri = Uri.parse(url)
        try {
            val i = Intent(Intent.ACTION_VIEW, uri)
            i.setPackage("com.android.chrome")
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            safeStart(Intent(Intent.ACTION_VIEW, uri))
        }
    }

    private fun openChrome() {
        val i = packageManager.getLaunchIntentForPackage("com.android.chrome")
        if (i != null) safeStart(i) else openUrl("https://www.google.com")
    }

    private fun openWeather() {
        val i = Intent(this, WebActivity::class.java)
        i.putExtra("url", "https://www.wetter.de")
        i.putExtra("title", "Wetter")
        startActivity(i)
    }

    // ---------------------------------------------------------------- App-Liste

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.activityInfo.name, it.loadIcon(pm)) }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                apps = list
                filterApps(drawerSearch.text.toString())
            }
        }.start()
    }

    private fun filterApps(q: String) {
        val t = q.trim()
        shown = if (t.isEmpty()) apps else apps.filter { it.label.contains(t, ignoreCase = true) }
        adapter.notifyDataSetChanged()
    }

    private fun openDrawer(focus: Boolean) {
        drawer.alpha = 0f
        drawer.visibility = View.VISIBLE
        drawer.animate().alpha(1f).setDuration(160).start()
        if (focus) {
            drawerSearch.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            drawerSearch.post { imm.showSoftInput(drawerSearch, InputMethodManager.SHOW_IMPLICIT) }
        }
    }

    private fun closeDrawer() {
        if (drawer.visibility != View.VISIBLE) return
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(drawerSearch.windowToken, 0)
        drawerSearch.setText("")
        drawerSearch.clearFocus()
        drawer.visibility = View.GONE
    }

    private fun appMenu(app: AppEntry) {
        choose(app.label, listOf(
            "Auf den Desktop legen" to {
                val neu = Item(newId(), T.APP, app.label, app.component, pendFx, pendFy)
                pendFx = if (pendFx > 0.7f) 0.06f else pendFx + 0.05f
                pendFy = if (pendFy > 0.8f) 0.55f else pendFy + 0.02f
                addItem(neu)
                closeDrawer()
                toast("Auf den Desktop gelegt")
            },
            "App-Info" to {
                safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.pkg)))
            }
        ))
    }

    inner class AppAdapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val g = store.iconScale / 100f
            val box: LinearLayout
            if (convertView is LinearLayout) {
                box = convertView
            } else {
                box = LinearLayout(this@MainActivity)
                box.orientation = LinearLayout.VERTICAL
                box.gravity = Gravity.CENTER_HORIZONTAL
                box.setPadding(0, dpi(4f), 0, dpi(4f))
                box.addView(ImageView(this@MainActivity))
                val tv = TextView(this@MainActivity)
                tv.maxLines = 1
                tv.ellipsize = TextUtils.TruncateAt.END
                tv.gravity = Gravity.CENTER
                box.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP))
            }
            val a = shown[position]
            val img = box.getChildAt(0) as ImageView
            val px = dpi(52f * g)
            img.layoutParams = LinearLayout.LayoutParams(px, px)
            img.setImageDrawable(a.icon)
            val tv = box.getChildAt(1) as TextView
            tv.text = a.label
            tv.textSize = (11f * g).coerceIn(9f, 16f)
            tv.setTextColor(tm.text)
            return box
        }
    }
}
