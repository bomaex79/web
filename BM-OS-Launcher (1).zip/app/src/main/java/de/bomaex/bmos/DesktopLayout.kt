package de.bomaex.bmos

import android.content.Context
import android.view.GestureDetector
import android.view.MotionEvent
import android.widget.FrameLayout

/** Desktop-Fläche: Wischen nach oben = App-Liste, langes Drücken auf freie Fläche = Menü. */
class DesktopLayout(ctx: Context) : FrameLayout(ctx) {
    var onSwipeUp: (() -> Unit)? = null
    var onLongPressAt: ((Float, Float) -> Unit)? = null

    private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onLongPress(e: MotionEvent) {
            onLongPressAt?.invoke(e.x, e.y)
        }

        override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
            if (e1 != null && e1.y - e2.y > 120f && velocityY < -800f) {
                onSwipeUp?.invoke()
                return true
            }
            return false
        }
    })

    override fun onTouchEvent(event: MotionEvent): Boolean {
        gd.onTouchEvent(event)
        return true
    }
}
