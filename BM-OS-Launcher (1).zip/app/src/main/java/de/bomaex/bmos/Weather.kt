package de.bomaex.bmos

import android.app.Activity
import android.app.AlertDialog
import android.widget.EditText
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class Place(val title: String, val city: String, val lat: Double, val lon: Double)

/** Wetterdaten über Open-Meteo (kostenlos, ohne Schlüssel). wetter.de bietet keine offene Schnittstelle. */
object Weather {

    fun describe(code: Int): Pair<String, String> = when (code) {
        0 -> "☀️" to "Klar"
        1 -> "🌤️" to "Überwiegend klar"
        2 -> "⛅" to "Wolkig"
        3 -> "☁️" to "Bedeckt"
        45, 48 -> "🌫️" to "Nebel"
        51, 53, 55, 56, 57 -> "🌦️" to "Nieselregen"
        61, 63, 65, 66, 67 -> "🌧️" to "Regen"
        71, 73, 75, 77 -> "❄️" to "Schnee"
        80, 81, 82 -> "🌦️" to "Schauer"
        85, 86 -> "🌨️" to "Schneeschauer"
        95, 96, 99 -> "⛈️" to "Gewitter"
        else -> "🌡️" to "Wetter"
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun search(name: String): List<Place> {
        val url = "https://geocoding-api.open-meteo.com/v1/search?count=6&language=de&format=json&name=" +
            URLEncoder.encode(name, "UTF-8")
        val arr = JSONObject(get(url)).optJSONArray("results") ?: return emptyList()
        val out = mutableListOf<Place>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val city = o.optString("name")
            val parts = listOf(city, o.optString("admin1"), o.optString("country")).filter { it.isNotBlank() }
            out.add(Place(parts.joinToString(", "), city, o.getDouble("latitude"), o.getDouble("longitude")))
        }
        return out
    }

    /** Lädt neue Daten, wenn die gespeicherten älter als 30 Minuten sind. onDone läuft im Hintergrund-Thread. */
    fun refreshIfStale(store: Store, force: Boolean = false, onDone: () -> Unit) {
        if (store.weatherName.isEmpty()) return
        val now = System.currentTimeMillis()
        if (!force && (now - store.weatherTime < 30 * 60_000L || now - store.weatherTried < 2 * 60_000L)) return
        store.weatherTried = now
        val lat = store.weatherLat
        val lon = store.weatherLon
        Thread {
            try {
                val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min" +
                    "&timezone=auto&forecast_days=1"
                val o = JSONObject(get(url))
                val cur = o.getJSONObject("current")
                val daily = o.getJSONObject("daily")
                store.weatherTemp = cur.getDouble("temperature_2m").toFloat()
                store.weatherCode = cur.getInt("weather_code")
                store.weatherMax = daily.getJSONArray("temperature_2m_max").getDouble(0).toFloat()
                store.weatherMin = daily.getJSONArray("temperature_2m_min").getDouble(0).toFloat()
                store.weatherTime = System.currentTimeMillis()
                onDone()
            } catch (e: Exception) {
                // bleibt beim letzten Stand, nächster Versuch nach 2 Minuten
            }
        }.start()
    }

    fun pickLocation(a: Activity, store: Store, onDone: () -> Unit) {
        val et = EditText(a)
        et.hint = "Ort, z. B. Stolberg"
        et.setSingleLine(true)
        AlertDialog.Builder(a)
            .setTitle("Wetter-Ort")
            .setView(et)
            .setPositiveButton("Suchen") { _, _ ->
                val q = et.text.toString().trim()
                if (q.isNotEmpty()) {
                    Toast.makeText(a, "Suche …", Toast.LENGTH_SHORT).show()
                    Thread {
                        val res: List<Place>? = try { search(q) } catch (e: Exception) { null }
                        a.runOnUiThread {
                            if (res == null) {
                                Toast.makeText(a, "Keine Internetverbindung", Toast.LENGTH_LONG).show()
                            } else if (res.isEmpty()) {
                                Toast.makeText(a, "Ort nicht gefunden", Toast.LENGTH_LONG).show()
                            } else {
                                AlertDialog.Builder(a)
                                    .setTitle("Ort wählen")
                                    .setItems(res.map { it.title }.toTypedArray()) { _, i ->
                                        val p = res[i]
                                        store.weatherName = p.city
                                        store.weatherLat = p.lat
                                        store.weatherLon = p.lon
                                        store.weatherTime = 0L
                                        store.weatherTried = 0L
                                        onDone()
                                        refreshIfStale(store, true) { a.runOnUiThread { onDone() } }
                                    }
                                    .show()
                            }
                        }
                    }.start()
                }
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }
}
