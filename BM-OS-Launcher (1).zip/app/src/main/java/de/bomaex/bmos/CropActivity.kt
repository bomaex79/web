package de.bomaex.bmos

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.FileOutputStream

class CropActivity : Activity() {

    private lateinit var crop: CropView
    private var sw = 1080
    private var sh = 2400

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri = intent.data
        val bmp = if (uri != null) loadBitmap(uri) else null
        if (bmp == null) {
            Toast.makeText(this, "Bild konnte nicht geladen werden", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(dm)
        sw = dm.widthPixels
        sh = dm.heightPixels

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#071A2E"))

        val hint = TextView(this)
        hint.text = "Bild verschieben und mit zwei Fingern zoomen"
        hint.setTextColor(Color.WHITE)
        hint.gravity = Gravity.CENTER
        hint.setPadding(0, dpi(40f), 0, dpi(10f))
        root.addView(hint, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        crop = CropView(this, bmp, sw.toFloat() / sh.toFloat())
        root.addView(crop, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER
        bar.setPadding(dpi(12f), dpi(10f), dpi(12f), dpi(24f))
        val cancel = Button(this)
        cancel.text = "Abbrechen"
        cancel.setOnClickListener { setResult(RESULT_CANCELED); finish() }
        val save = Button(this)
        save.text = "Zuschneiden & speichern"
        save.setOnClickListener { saveCrop() }
        bar.addView(cancel, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(save, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f))
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
    }

    private fun saveCrop() {
        try {
            val out = crop.renderCrop(sw, sh)
            val f = Store(this).wallpaperFile
            FileOutputStream(f).use { out.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            setResult(RESULT_OK)
            finish()
        } catch (e: Throwable) {
            Toast.makeText(this, "Speichern fehlgeschlagen", Toast.LENGTH_LONG).show()
        }
    }

    private fun loadBitmap(uri: Uri): Bitmap? {
        try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 2600 || bounds.outHeight / sample > 2600) sample *= 2
            val o = BitmapFactory.Options()
            o.inSampleSize = sample
            var bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } ?: return null
            var orientation = ExifInterface.ORIENTATION_NORMAL
            try {
                contentResolver.openInputStream(uri)?.use {
                    orientation = ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                }
            } catch (e: Exception) { }
            val m = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            }
            if (!m.isIdentity) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            return bmp
        } catch (e: Throwable) {
            return null
        }
    }
}
