package de.bomaex.bmos

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.max

/** Bild verschieben und zoomen; der helle Rahmen hat das Seitenverhältnis des Bildschirms. */
class CropView(ctx: Context, private val bmp: Bitmap, private val aspect: Float) : View(ctx) {

    private val m = Matrix()
    private val frame = RectF()
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val dim = Paint().apply { color = Color.argb(170, 0, 0, 0) }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * ctx.resources.displayMetrics.density
        color = Color.WHITE
    }
    private var minScale = 1f
    private var lx = 0f
    private var ly = 0f

    private val sd = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            zoom(d.scaleFactor, d.focusX, d.focusY)
            return true
        }
    })

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val pad = 20f * resources.displayMetrics.density
        val aw = w - 2 * pad
        val ah = h - 2 * pad
        var fw = aw
        var fh = fw / aspect
        if (fh > ah) {
            fh = ah
            fw = fh * aspect
        }
        frame.set((w - fw) / 2f, (h - fh) / 2f, (w + fw) / 2f, (h + fh) / 2f)
        minScale = max(frame.width() / bmp.width, frame.height() / bmp.height)
        m.reset()
        m.postScale(minScale, minScale)
        m.postTranslate(frame.centerX() - bmp.width * minScale / 2f, frame.centerY() - bmp.height * minScale / 2f)
    }

    private fun curScale(): Float {
        val v = FloatArray(9)
        m.getValues(v)
        return v[Matrix.MSCALE_X]
    }

    private fun zoom(f: Float, fx: Float, fy: Float) {
        val cur = curScale()
        val target = (cur * f).coerceIn(minScale, minScale * 6f)
        val real = target / cur
        m.postScale(real, real, fx, fy)
        clamp()
        invalidate()
    }

    private fun clamp() {
        val r = RectF(0f, 0f, bmp.width.toFloat(), bmp.height.toFloat())
        m.mapRect(r)
        var dx = 0f
        var dy = 0f
        if (r.left > frame.left) dx = frame.left - r.left else if (r.right < frame.right) dx = frame.right - r.right
        if (r.top > frame.top) dy = frame.top - r.top else if (r.bottom < frame.bottom) dy = frame.bottom - r.bottom
        m.postTranslate(dx, dy)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        sd.onTouchEvent(e)
        if (!sd.isInProgress) {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y }
                MotionEvent.ACTION_MOVE -> if (e.pointerCount == 1) {
                    m.postTranslate(e.x - lx, e.y - ly)
                    clamp()
                    invalidate()
                    lx = e.x; ly = e.y
                }
                MotionEvent.ACTION_POINTER_UP -> {
                    val i = if (e.actionIndex == 0) 1 else 0
                    lx = e.getX(i); ly = e.getY(i)
                }
            }
        } else {
            lx = e.x; ly = e.y
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.parseColor("#071A2E"))
        c.drawBitmap(bmp, m, paint)
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRect(0f, 0f, w, frame.top, dim)
        c.drawRect(0f, frame.bottom, w, h, dim)
        c.drawRect(0f, frame.top, frame.left, frame.bottom, dim)
        c.drawRect(frame.right, frame.top, w, frame.bottom, dim)
        c.drawRect(frame, border)
    }

    /** Liefert den gewählten Ausschnitt in der gewünschten Zielgröße. */
    fun renderCrop(outW: Int, outH: Int): Bitmap {
        val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val k = outW / frame.width()
        c.scale(k, k)
        c.translate(-frame.left, -frame.top)
        c.drawBitmap(bmp, m, paint)
        return out
    }
}
