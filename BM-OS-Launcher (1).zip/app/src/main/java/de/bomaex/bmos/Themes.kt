package de.bomaex.bmos

import android.graphics.Color

class BmTheme(
    val id: String,
    val name: String,
    val bg: IntArray,
    val text: Int,
    val accent: Int,
    val card: Int,
    val light: Boolean = false
)

object Themes {
    private fun c(s: String) = Color.parseColor(s)

    val all: List<BmTheme> = listOf(
        // Standard: Farben aus dem BM-Logo / bomaex.de (Marineblau mit hellblauem Akzent)
        BmTheme("bm", "BM Standard (wie bomaex.de)", intArrayOf(c("#12395E"), c("#071A2E"), c("#030B15")), c("#FFFFFF"), c("#3DA9ED"), c("#38FFFFFF")),
        BmTheme("midnight", "Mitternacht", intArrayOf(c("#2A1A4A"), c("#120B24"), c("#05030C")), c("#FFFFFF"), c("#B388FF"), c("#33FFFFFF")),
        BmTheme("pride", "Regenbogen", intArrayOf(c("#2B1055"), c("#1A1040"), c("#0B0820")), c("#FFFFFF"), c("#FF5CA8"), c("#38FFFFFF")),
        BmTheme("forest", "Wald", intArrayOf(c("#1F4D3A"), c("#0F2B20"), c("#06130E")), c("#FFFFFF"), c("#5FD38D"), c("#33FFFFFF")),
        BmTheme("sunset", "Sonnenuntergang", intArrayOf(c("#5A2145"), c("#2E1130"), c("#12060F")), c("#FFFFFF"), c("#FF9A5C"), c("#33FFFFFF")),
        BmTheme("light", "Hell", intArrayOf(c("#F4F8FC"), c("#DCEBF7"), c("#C3DCF0")), c("#0B2540"), c("#287FC2"), c("#99FFFFFF"), true)
    )

    fun byId(id: String): BmTheme = all.firstOrNull { it.id == id } ?: all[0]
}
