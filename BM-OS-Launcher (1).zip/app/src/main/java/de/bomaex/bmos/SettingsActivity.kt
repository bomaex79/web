package de.bomaex.bmos

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {

    private val REQ_PICK = 601
    private val REQ_CROP = 602
    private lateinit var store: Store
    private lateinit var box: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#071A2E"))
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dpi(20f), dpi(36f), dpi(20f), dpi(32f))
        scroll.addView(box)
        setContentView(scroll)
        build()
        if (intent.getBooleanExtra("pick", false)) pickWallpaper()
    }

    private fun title(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(Color.parseColor("#3DA9ED"))
        tv.textSize = 13f
        tv.setPadding(0, dpi(22f), 0, dpi(6f))
        return tv
    }

    private fun row(t: String, sub: String? = null, click: () -> Unit): View {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dpi(16f), dpi(14f), dpi(16f), dpi(14f))
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#26FFFFFF"))
        bg.cornerRadius = dp(14f)
        l.background = bg
        val a = TextView(this)
        a.text = t
        a.setTextColor(Color.WHITE)
        a.textSize = 16f
        l.addView(a)
        if (sub != null) {
            val b = TextView(this)
            b.text = sub
            b.setTextColor(Color.parseColor("#B8CFE3"))
            b.textSize = 12f
            l.addView(b)
        }
        l.setOnClickListener { click() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dpi(8f)
        l.layoutParams = lp
        return l
    }

    private fun switchRow(t: String, on: Boolean, change: (Boolean) -> Unit): View {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        l.setPadding(dpi(16f), dpi(10f), dpi(16f), dpi(10f))
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#26FFFFFF"))
        bg.cornerRadius = dp(14f)
        l.background = bg
        val a = TextView(this)
        a.text = t
        a.setTextColor(Color.WHITE)
        a.textSize = 16f
        l.addView(a, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this)
        sw.isChecked = on
        sw.setOnCheckedChangeListener { _, c -> change(c) }
        l.addView(sw)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dpi(8f)
        l.layoutParams = lp
        return l
    }

    private fun build() {
        box.removeAllViews()
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_bm_logo)
        box.addView(logo, LinearLayout.LayoutParams(dpi(150f), dpi(110f)))
        val h = TextView(this)
        h.text = "BM OS Einstellungen"
        h.setTextColor(Color.WHITE)
        h.textSize = 22f
        h.setPadding(0, dpi(8f), 0, 0)
        box.addView(h)

        box.addView(title("DESIGN"))
        val cur = Themes.byId(store.themeId)
        box.addView(row("Design wählen", cur.name) {
            val names = Themes.all.map { it.name }.toTypedArray()
            val sel = Themes.all.indexOfFirst { it.id == cur.id }.coerceAtLeast(0)
            AlertDialog.Builder(this)
                .setTitle("Design")
                .setSingleChoiceItems(names, sel) { d, i ->
                    store.themeId = Themes.all[i].id
                    d.dismiss()
                    build()
                }
                .show()
        })

        box.addView(title("DESKTOP"))
        box.addView(switchRow("Uhr anzeigen", store.clockOn) { store.clockOn = it })
        box.addView(row("Wetter-Ort", if (store.weatherName.isEmpty()) "Noch nicht festgelegt" else store.weatherName) {
            Weather.pickLocation(this, store) { build() }
        })
        box.addView(switchRow("Symbolnamen anzeigen", store.labels) { store.labels = it })

        val sizeLabel = TextView(this)
        sizeLabel.setTextColor(Color.WHITE)
        sizeLabel.textSize = 15f
        sizeLabel.text = "Symbolgröße (alle): " + store.iconScale + " %"
        sizeLabel.setPadding(dpi(4f), dpi(10f), 0, 0)
        box.addView(sizeLabel)
        val sb = SeekBar(this)
        sb.max = 100
        sb.progress = store.iconScale - 60
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                store.iconScale = p + 60
                sizeLabel.text = "Symbolgröße (alle): " + (p + 60) + " %"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(sb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val tip = TextView(this)
        tip.text = "Tipp: Einzelne Symbole und Widgets ändern Sie auf dem Desktop per langem Drücken → „Größe ändern“."
        tip.setTextColor(Color.parseColor("#B8CFE3"))
        tip.textSize = 12f
        tip.setPadding(dpi(4f), dpi(4f), 0, dpi(8f))
        box.addView(tip)

        box.addView(title("HINTERGRUND"))
        box.addView(row("Eigenes Hintergrundbild wählen", "Mit Zuschneiden und Zoomen") { pickWallpaper() })
        box.addView(row("Hintergrundbild entfernen", "Zurück zum Design-Hintergrund") {
            store.wallpaperFile.delete()
            Toast.makeText(this, "Hintergrundbild entfernt", Toast.LENGTH_SHORT).show()
        })

        box.addView(title("LAUNCHER"))
        box.addView(row("Als Standard-Launcher festlegen") {
            try {
                startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            } catch (e: Exception) {
                try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e2: Exception) { }
            }
        })
        box.addView(row("Desktop zurücksetzen", "Standard-Symbole und Widgets wiederherstellen") {
            AlertDialog.Builder(this)
                .setTitle("Desktop zurücksetzen?")
                .setMessage("Alle eigenen Anordnungen, Ordner und Widgets gehen verloren.")
                .setPositiveButton("Zurücksetzen") { _, _ ->
                    store.reset()
                    store.clockOn = true
                    Toast.makeText(this, "Desktop zurückgesetzt", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Abbrechen", null)
                .show()
        })

        box.addView(title("RECHTLICHES"))
        box.addView(row("Impressum & Datenschutz") { startActivity(Intent(this, InfoActivity::class.java)) })
        box.addView(row("Webseite Bo Maex™", "www.bomaex.de") {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.bomaex.de"))) } catch (e: Exception) { }
        })
        val v = TextView(this)
        v.text = "BM OS 1.0 · © Bo Maex Schneider"
        v.setTextColor(Color.parseColor("#7F9AB3"))
        v.textSize = 12f
        v.setPadding(dpi(4f), dpi(18f), 0, 0)
        box.addView(v)
    }

    private fun pickWallpaper() {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(i, REQ_PICK)
        } catch (e: Exception) {
            Toast.makeText(this, "Keine Galerie-App gefunden", Toast.LENGTH_SHORT).show()
        }
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK && resultCode == RESULT_OK && data?.data != null) {
            val c = Intent(this, CropActivity::class.java)
            c.data = data.data
            c.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            @Suppress("DEPRECATION")
            startActivityForResult(c, REQ_CROP)
        } else if (requestCode == REQ_CROP && resultCode == RESULT_OK) {
            Toast.makeText(this, "Hintergrundbild gesetzt", Toast.LENGTH_SHORT).show()
        }
    }
}
